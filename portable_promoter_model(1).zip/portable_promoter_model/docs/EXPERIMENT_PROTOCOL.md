# Experiment Protocol

## Fixed Design

主实验固定为 gene/promoter split：

- train genes 更新模型。
- validation genes 选择 checkpoint。
- test genes 只用于最终报告。
- 所有细胞进入 sampling pool；不把 cell split 作为主结论轴。

## Required Runs

| Run | `--mode` | `--promoter-control` | `--contrastive-weight` |
| --- | --- | --- | --- |
| expression-only | `expression_only` | `matched` | `0` |
| matched promoter contrastive | `expression_plus_promoter` | `matched` | `0.1` |
| matched promoter no-contrast | `expression_plus_promoter` | `matched` | `0` |
| clean intergenic control | `expression_plus_promoter` | `intergenic_matched` | `0` |

Run all four with the same seeds. Recommended formal seeds: `1`, `7`, `42`.

## Contrastive Rule

The auxiliary triplet loss is:

- anchor: true promoter with random shift
- positive: same true promoter with another random shift
- negative: matched intergenic sequence

Therefore:

- Allowed: matched promoter with `contrastive_weight > 0`
- Not allowed: expression-only or intergenic control with `contrastive_weight > 0`

The training script enforces this rule.

## Checkpoint Rule

Use validation-gene RMSE for checkpoint selection. Do not choose checkpoints or tune hyperparameters based on test genes.

## Metrics To Report

Primary:

- RMSE
- MAE
- all-value Pearson/Spearman
- median per-gene correlation
- median per-cell correlation
- nonzero/zero RMSE
- expressed AUROC / average precision

Recommended table rows:

- validation genes, sampled cells
- test genes, sampled cells

## Interpretation

Promoter sequence value:

- matched promoter beats expression-only on unseen genes
- matched promoter beats clean intergenic control on unseen genes

Contrastive value:

- matched promoter contrastive beats matched promoter no-contrast

Do not claim:

- new-cell, new-donor, or new-tissue generalization from this protocol alone
- motif causality unless additional perturbation analysis is run
- species-wide biology if target genes were capped to a small subset
