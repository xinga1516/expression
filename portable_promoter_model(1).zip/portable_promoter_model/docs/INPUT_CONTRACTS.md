# Input Contracts

这个文档定义复现当前方法所需的最小输入格式。

## Single-Cell Atlas

输入是一组 `.h5ad` 文件，要求：

- 每个文件的 gene/feature 轴顺序一致。
- 表达矩阵位于 `layers/<expression_layer>`，默认 `log_normalized`。
- layer 使用 AnnData HDF5 中常见的 CSR layout: `data`, `indices`, `indptr`, `shape`。
- `.var` 中有稳定 gene id 列和 gene symbol 列；列名可通过 `--gene-id-column` 和 `--gene-symbol-column` 指定。
- `.obs` 最好包含 donor/sample/tissue/cell type 等信息；如果没有，index builder 会填空。当前主线不依赖这些列做 split。

## Reference Genome And GTF

需要：

- `genome.fa`
- `genome.fa.fai`
- `annotation.gtf`

Promoter builder 用 GTF 中的 transcript 记录选择一个 TSS：

1. 优先 `MANE_Select`
2. 其次 `Ensembl_canonical`
3. 如果都没有，选择该 gene 最长 transcript 作为 fallback

所有 gene id 会去掉版本后缀再匹配。

## Promoter Assets

由 `scripts/build_promoter_contexts.py` 生成：

- `gene_promoters.tsv`
- `promoter_contexts.uint8.npy`
- `summary.json`

`gene_promoters.tsv` 必要列：

| Column | Meaning |
| --- | --- |
| `feature_index` | `.h5ad` gene axis row |
| `gene_id` | versionless stable gene id |
| `input_gene_symbol` | readable gene symbol |
| `chrom` | chromosome/contig |
| `strand` | `+` or `-` |
| `tss_1based` | selected TSS |
| `context_row` | row in `promoter_contexts.uint8.npy` |
| `status` | usable rows should be `ok` |
| `sequence_qc` | preferred value is `pass` |

Sequence encoding:

- `A=0`
- `C=1`
- `G=2`
- `T=3`
- `N/other=4`

## Intergenic Assets

由 `scripts/build_intergenic_contexts.py` 生成：

- `gene_intergenic.tsv`
- `intergenic_contexts.uint8.npy`
- `summary.json`

`gene_intergenic.tsv` 必要列：

| Column | Meaning |
| --- | --- |
| `feature_index` | matched to the source gene |
| `context_row` | row in `intergenic_contexts.uint8.npy` |
| `selected_chrom` | sampled non-promoter chromosome |
| `selected_start_0based` | sampled interval start |
| `selected_end_0based_exclusive` | sampled interval end |
| `status` | preferred value is `ok` |
| `sequence_qc` | preferred value is `pass` |

## Gene Split Plan

`configs/templates/gene_split_plan.tsv` 的列：

| Column | Meaning |
| --- | --- |
| `chrom` | chromosome/contig name matching GTF/FASTA |
| `split` | `train`, `validation`, or `test` |
| `notes` | free text |

没有出现在该文件里的染色体默认进入 train。建议提前把特殊 contigs、sex chromosomes、mitochondrial chromosome 放进 train，除非有明确测试目的。

## Panel Directory

由 `scripts/build_gene_split_panels.py` 生成，训练脚本读取：

- `input_features.tsv`
- `target_genes.tsv`
- `panel_gene_metrics.tsv`
- `summary.json`

`input_features.tsv` 必要列：

| Column | Meaning |
| --- | --- |
| `input_position` | zero-based model input position |
| `feature_index` | `.h5ad` gene axis row |
| `gene_id` | stable gene id |
| `input_gene_symbol` | readable symbol |
| `gene_split` | should be `train` for all input genes |

`target_genes.tsv` 必要列：

| Column | Meaning |
| --- | --- |
| `target_index` | zero-based target row |
| `feature_index` | `.h5ad` gene axis row |
| `gene_id` | stable gene id |
| `gene_split` | `train`, `validation`, or `test` |
| `input_position` | input position if target is in input panel, otherwise `-1` |

## Cell Index

由 `scripts/build_cell_index.py` 生成：

- `cells/*.tsv.gz`
- `cells_manifest.tsv`
- `summary.json`

训练脚本用它把 global cell index 映射回原始 `.h5ad` 文件和 row。当前主线使用全部细胞作为 sampling pool，不需要 cell/context split。
