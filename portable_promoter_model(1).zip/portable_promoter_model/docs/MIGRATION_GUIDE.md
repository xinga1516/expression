# Migration Guide

目标：把当前 promoter 建模方法迁移到一个新物种或新单细胞 atlas。

建议先在一个小目录或少量 `.h5ad` 文件上跑通全流程，再扩展到全量数据。

## 0. Create Environment

```bash
conda env create -f environment.yml
conda activate portable-promoter-model
```

如果机器已有可用 PyTorch GPU 环境，也可以直接使用，但至少需要 `numpy`, `pandas`, `h5py`, `anndata`, `torch`。

## 1. Prepare Project Template

复制并填写：

- `configs/templates/species_project.yaml`
- `configs/templates/gene_split_plan.tsv`

关键决定：

- `.h5ad.var` 里哪个列是 stable gene id。
- GTF gene id 和 `.h5ad.var` gene id 是否能去版本号后匹配。
- validation/test 用哪些 chromosomes。
- 特殊 contigs 是否强制 train。

成功标准：

- `gene_split_plan.tsv` 中 validation/test chromosomes 是训练前确定的。
- `.h5ad.var` 的 gene id 可以和 GTF gene id 对齐。

## 2. Build Promoter Contexts

目的：为每个 gene 生成一个 strand-oriented promoter sequence。

```bash
python scripts/build_promoter_contexts.py \
  --h5ad /path/to/example_or_reference.h5ad \
  --gtf /path/to/annotation.gtf \
  --fasta /path/to/genome.fa \
  --output-dir data/processed/promoters \
  --context-radius 220 \
  --gene-id-column gene_id \
  --gene-symbol-column gene_symbol
```

成功标准：

- `data/processed/promoters/gene_promoters.tsv` 存在。
- 大多数目标 gene 的 `status=ok`。
- validation/test chromosomes 上的 `sequence_qc=pass` 比例足够高。

常见失败：

- `.h5ad.var` 列名不匹配：调整 `--gene-id-column` / `--gene-symbol-column`。
- GTF gene id 带版本而 `.h5ad` 不带版本：脚本会去版本后匹配。
- FASTA contig 名和 GTF contig 名不一致：需要统一 reference 命名。

## 3. Build Matched Intergenic Contexts

目的：为每个 gene 生成一个 matched non-promoter negative sequence。

```bash
python scripts/build_intergenic_contexts.py \
  --source-metadata data/processed/promoters/gene_promoters.tsv \
  --gtf /path/to/annotation.gtf \
  --fasta /path/to/genome.fa \
  --output-dir data/processed/intergenic \
  --context-radius 220 \
  --gene-padding 1000 \
  --seed 1
```

成功标准：

- `gene_intergenic.tsv` 中大多数 promoter-ok gene 也有 `status=ok`。
- `ok_fallback_chrom` 很少；validation/test genes 最好没有 fallback。

逻辑：

- 先从 GTF 收集所有 annotated gene intervals。
- 每个 interval 两侧加 `--gene-padding`。
- 在剩余 intergenic pool 中抽取长度相同的窗口。
- 优先从 source gene 的同一 chromosome 抽取。

## 4. Build Cell Index

目的：训练时不把整个 atlas 读进内存，而是通过 index 定位每个 cell 的源文件和 row。

```bash
python scripts/build_cell_index.py \
  --input-dir /path/to/h5ad_dir \
  --output-dir outputs/training_index
```

如果 `.obs` 缺少 donor/sample/tissue 等列，脚本会填空。当前主线不使用 cell split，因此这些列只用于记录和后续诊断。

成功标准：

- `outputs/training_index/cells_manifest.tsv` 存在。
- `summary.json` 中 `n_cells` 符合预期。

## 5. Build Gene-Split Panels

目的：

- 从 train genes 中选择 input genes。
- 把 promoter-ok genes 按 chromosome split 写成 target panel。
- 记录 target gene 是否出现在 input panel 中，供训练时动态 mask。

```bash
python scripts/build_gene_split_panels.py \
  --input-dir /path/to/h5ad_dir \
  --promoter-metadata data/processed/promoters/gene_promoters.tsv \
  --gene-split-plan configs/gene_split_plan.tsv \
  --output-dir outputs/gene_split_panel \
  --expression-layer log_normalized \
  --n-input-features 4096 \
  --n-target-features 0 \
  --seed 1
```

`--n-target-features 0` 表示保留全部 promoter-ok target genes。若数据太大，可设为正数做表达分层子集，但正式结论要说明 target universe。

成功标准：

- `input_features.tsv` 全部来自 train genes。
- `target_genes.tsv` 同时包含 train/validation/test genes。
- validation/test target genes 和 input panel 的重叠应为 0 或被 `input_position` 正确记录后在训练中 mask。

## 6. Run The Four Models

所有模型必须使用同一个：

- gene split
- cell index
- input/target panel
- promoter/intergenic assets
- seeds
- optimizer and sampling defaults

Expression-only:

```bash
python scripts/train_promoter_model.py \
  --task-config configs/training/promoter_model.json \
  --input-dir /path/to/h5ad_dir \
  --index-dir outputs/training_index \
  --panel-dir outputs/gene_split_panel \
  --promoter-dir data/processed/promoters \
  --output-dir outputs/run_expression_seed1 \
  --mode expression_only \
  --contrastive-weight 0 \
  --seed 1 \
  --device cuda:0
```

Matched promoter with contrastive loss:

```bash
python scripts/train_promoter_model.py \
  --task-config configs/training/promoter_model.json \
  --input-dir /path/to/h5ad_dir \
  --index-dir outputs/training_index \
  --panel-dir outputs/gene_split_panel \
  --promoter-dir data/processed/promoters \
  --intergenic-dir data/processed/intergenic \
  --output-dir outputs/run_matched_contrastive_seed1 \
  --mode expression_plus_promoter \
  --promoter-control matched \
  --contrastive-weight 0.1 \
  --seed 1 \
  --device cuda:0
```

Matched promoter without contrastive loss:

```bash
python scripts/train_promoter_model.py \
  --task-config configs/training/promoter_model.json \
  --input-dir /path/to/h5ad_dir \
  --index-dir outputs/training_index \
  --panel-dir outputs/gene_split_panel \
  --promoter-dir data/processed/promoters \
  --intergenic-dir data/processed/intergenic \
  --output-dir outputs/run_matched_nocontrast_seed1 \
  --mode expression_plus_promoter \
  --promoter-control matched \
  --contrastive-weight 0 \
  --seed 1 \
  --device cuda:0
```

Clean intergenic control:

```bash
python scripts/train_promoter_model.py \
  --task-config configs/training/promoter_model.json \
  --input-dir /path/to/h5ad_dir \
  --index-dir outputs/training_index \
  --panel-dir outputs/gene_split_panel \
  --promoter-dir data/processed/promoters \
  --intergenic-dir data/processed/intergenic \
  --output-dir outputs/run_intergenic_seed1 \
  --mode expression_plus_promoter \
  --promoter-control intergenic_matched \
  --contrastive-weight 0 \
  --seed 1 \
  --device cuda:0
```

## 7. Inspect Outputs

每个 run 输出：

- `summary.json`
- `history.json`
- `best_model.pt`

优先看：

- `best_val_rmse`
- `evaluations.validation_cells_validation_genes`
- `evaluations.test_cells_test_genes`

正式结论至少跑 seeds `1`, `7`, `42`。
