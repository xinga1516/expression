# Method Summary

## Problem

给定一个单细胞和一个目标基因，预测这个目标基因在该细胞中的表达量。

模型输入包含两部分：

- `cell input`: 同一个细胞中一组 input genes 的表达量。
- `sequence input`: 目标基因的 promoter 序列窗口。

如果目标基因也出现在 input genes 中，训练和评估时会把该位置置零，避免模型直接复制目标表达量。

## Main Split

主科学划分只按 gene/promoter 做：

- `train genes`: 用来更新模型权重。
- `validation genes`: 用来选 checkpoint 和调试方案。
- `test genes`: 最终报告前不使用。

细胞不作为主测试轴。所有细胞进入训练采样池，validation/test 只是在同一细胞池上换成 unseen genes 做评估。这样可以直接测试 promoter 序列对新基因泛化是否有帮助。

## Sequence Assets

每个 gene 需要两个序列资产：

- `promoter`: 以一个 canonical TSS 为中心，按转录方向统一为 downstream 在右侧。
- `intergenic`: 同一个 gene 匹配一个非基因区域窗口，优先来自同一染色体，并排除所有 annotated gene interval 加 padding。

训练默认缓存 441 bp 序列，实际输入为 401 bp。训练时对 promoter 做随机 shift；评估时用中心窗口。

## Model

模型结构分两支：

- cell branch: MLP 编码 input gene expression。
- promoter branch: base embedding + CNN + BiLSTM 编码 promoter/intergenic 序列。

两支拼接后经过 regressor 输出一个标量表达量。`expression_only` 模型禁用 sequence branch。

## Contrastive Loss

matched promoter run 可加一个辅助 triplet loss：

- anchor: true promoter 的一个随机 shift。
- positive: 同一个 true promoter 的另一个随机 shift。
- negative: matched intergenic sequence。

这个 loss 只允许用于 true matched promoter 输入。intergenic control 和 expression-only 必须设 `contrastive_weight=0`。

## Minimal Evidence Ladder

同一 gene split、同一细胞池、同一 seeds 下运行：

1. `expression_only`
2. `matched promoter, contrastive_weight=0.1`
3. `matched promoter, contrastive_weight=0`
4. `intergenic_matched, contrastive_weight=0`

解释逻辑：

- matched promoter 优于 expression-only: 序列输入带来增益。
- matched promoter 优于 intergenic control: 增益来自启动子匹配信息，而不是一般非启动子序列。
- contrastive matched promoter 优于 no-contrast matched promoter: intergenic negative 的辅助训练有额外价值。
