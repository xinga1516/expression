"""Portable promoter-model data utilities."""
