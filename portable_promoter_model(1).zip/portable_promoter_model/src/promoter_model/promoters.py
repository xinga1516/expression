"""Utilities for fast promoter shift augmentation."""

from __future__ import annotations

import numpy as np


CONTEXT_RADIUS = 220
PROMOTER_RADIUS = 200
CONTEXT_LENGTH = 2 * CONTEXT_RADIUS + 1
PROMOTER_LENGTH = 2 * PROMOTER_RADIUS + 1
MAX_SHIFT = CONTEXT_RADIUS - PROMOTER_RADIUS


def infer_context_radius(contexts: np.ndarray) -> int:
    contexts = np.asarray(contexts)
    if contexts.ndim == 1:
        length = contexts.shape[0]
    elif contexts.ndim == 2:
        length = contexts.shape[1]
    else:
        raise ValueError("contexts must have shape [length] or [batch, length]")
    if length % 2 != 1:
        raise ValueError(f"context length must be odd, got {length}")
    return length // 2


def slice_shifted_contexts(
    contexts: np.ndarray,
    shifts: np.ndarray | int,
    promoter_radius: int = PROMOTER_RADIUS,
    context_radius: int | None = None,
) -> np.ndarray:
    """Slice promoter windows from strand-oriented contexts.

    Positive shifts move downstream in transcriptional orientation.
    """
    contexts = np.asarray(contexts)
    if contexts.ndim == 1:
        contexts = contexts[None, :]
        squeeze = True
    elif contexts.ndim == 2:
        squeeze = False
    else:
        raise ValueError("contexts must have shape [length] or [batch, length]")

    if context_radius is None:
        context_radius = infer_context_radius(contexts)
    expected_length = 2 * context_radius + 1
    if contexts.shape[1] != expected_length:
        raise ValueError(
            f"context length must be {expected_length}, got {contexts.shape[1]}"
        )
    if not 0 < promoter_radius <= context_radius:
        raise ValueError(
            f"promoter_radius must be within (0, {context_radius}], got {promoter_radius}"
        )

    shifts = np.asarray(shifts, dtype=np.int64)
    if shifts.ndim == 0:
        shifts = np.full(contexts.shape[0], shifts.item(), dtype=np.int64)
    if shifts.shape != (contexts.shape[0],):
        raise ValueError("shifts must be scalar or have shape [batch]")
    max_shift = context_radius - promoter_radius
    if np.any((shifts < -max_shift) | (shifts > max_shift)):
        raise ValueError(f"shifts must be within [-{max_shift}, {max_shift}]")

    promoter_length = 2 * promoter_radius + 1
    starts = context_radius - promoter_radius + shifts
    indices = starts[:, None] + np.arange(promoter_length)[None, :]
    result = np.take_along_axis(contexts, indices, axis=1)
    return result[0] if squeeze else result


def sample_shifts(
    batch_size: int,
    rng: np.random.Generator,
    max_shift: int = MAX_SHIFT,
) -> np.ndarray:
    """Sample inclusive integer shifts for a training batch."""
    if max_shift < 0:
        raise ValueError("max_shift must be non-negative")
    return rng.integers(-max_shift, max_shift + 1, size=batch_size)

