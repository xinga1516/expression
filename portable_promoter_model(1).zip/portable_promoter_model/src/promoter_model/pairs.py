"""Cell-gene pair sampling and target-expression masking."""

from __future__ import annotations

import numpy as np


def sample_pair_indices(
    cell_indices: np.ndarray,
    n_targets: int,
    targets_per_cell: int,
    rng: np.random.Generator,
) -> tuple[np.ndarray, np.ndarray]:
    """Sample target genes without materializing the cell-gene Cartesian set."""
    cells = np.asarray(cell_indices, dtype=np.int64)
    if cells.ndim != 1:
        raise ValueError("cell_indices must be one-dimensional")
    if n_targets <= 0 or targets_per_cell <= 0:
        raise ValueError("n_targets and targets_per_cell must be positive")

    pair_cells = np.repeat(cells, targets_per_cell)
    pair_targets = rng.integers(
        0, n_targets, size=pair_cells.size, dtype=np.int64
    )
    return pair_cells, pair_targets


def mask_target_expression(
    expression: np.ndarray,
    target_input_positions: np.ndarray,
    mask_value: float = 0.0,
    copy: bool = True,
) -> tuple[np.ndarray, np.ndarray]:
    """Mask target values when a target is present in the fixed input panel.

    Positions below zero indicate that the target gene is not an input feature.
    The returned boolean vector records which rows were modified.
    """
    values = np.asarray(expression)
    positions = np.asarray(target_input_positions, dtype=np.int64)
    if values.ndim != 2:
        raise ValueError("expression must have shape [batch, input_features]")
    if positions.shape != (values.shape[0],):
        raise ValueError("target_input_positions must have shape [batch]")
    if np.any(positions >= values.shape[1]):
        raise ValueError("target input position is outside the expression panel")

    result = values.copy() if copy else values
    present = positions >= 0
    rows = np.flatnonzero(present)
    result[rows, positions[present]] = mask_value
    return result, present



def build_pair_batch(
    input_expression: np.ndarray,
    target_expression: np.ndarray,
    target_input_positions: np.ndarray,
    cell_indices: np.ndarray,
    target_indices: np.ndarray,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Gather a pair batch, mask target leakage, and return scalar labels."""
    inputs = np.asarray(input_expression)
    targets = np.asarray(target_expression)
    target_positions = np.asarray(target_input_positions, dtype=np.int64)
    cells = np.asarray(cell_indices, dtype=np.int64)
    genes = np.asarray(target_indices, dtype=np.int64)

    if inputs.ndim != 2 or targets.ndim != 2:
        raise ValueError("input and target expression must be two-dimensional")
    if inputs.shape[0] != targets.shape[0]:
        raise ValueError("input and target expression must share cell rows")
    if target_positions.shape != (targets.shape[1],):
        raise ValueError("target_input_positions must match target columns")
    if cells.shape != genes.shape or cells.ndim != 1:
        raise ValueError("cell_indices and target_indices must be matching vectors")
    if np.any((cells < 0) | (cells >= inputs.shape[0])):
        raise ValueError("cell index is out of range")
    if np.any((genes < 0) | (genes >= targets.shape[1])):
        raise ValueError("target index is out of range")

    batch_inputs = inputs[cells]
    batch_positions = target_positions[genes]
    masked_inputs, target_in_panel = mask_target_expression(
        batch_inputs, batch_positions, copy=True
    )
    labels = targets[cells, genes]
    return masked_inputs, labels, target_in_panel
