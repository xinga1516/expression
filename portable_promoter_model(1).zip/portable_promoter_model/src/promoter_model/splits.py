"""Deterministic stratified splits for target genes."""

from __future__ import annotations

import numpy as np
import pandas as pd


def _quantile_bin(values: pd.Series, bins: int) -> pd.Series:
    ranked = values.rank(method="first")
    return pd.qcut(ranked, q=bins, labels=False, duplicates="drop")


def stratified_gene_split(
    genes: pd.DataFrame,
    seed: int,
    train_fraction: float = 0.70,
    val_fraction: float = 0.15,
    bins: int = 4,
) -> np.ndarray:
    """Split genes while balancing expression-property quantiles."""
    required = {
        "train_detection_fraction",
        "train_log_mean",
        "train_log_variance",
    }
    missing = required - set(genes.columns)
    if missing:
        raise ValueError(f"missing stratification columns: {sorted(missing)}")
    if not 0 < train_fraction < 1:
        raise ValueError("train_fraction must be within (0, 1)")
    if not 0 < val_fraction < 1 - train_fraction:
        raise ValueError("val_fraction must leave a positive test fraction")

    strata = pd.DataFrame(
        {
            column: _quantile_bin(genes[column], bins)
            for column in sorted(required)
        }
    ).astype(str).agg("|".join, axis=1)

    rng = np.random.default_rng(seed)
    split = np.full(len(genes), "train", dtype=object)
    for stratum in sorted(strata.unique()):
        indices = np.flatnonzero(strata.to_numpy() == stratum)
        indices = rng.permutation(indices)
        n = len(indices)
        n_val = max(1, round(n * val_fraction)) if n >= 3 else 0
        n_test = max(1, n - round(n * (train_fraction + val_fraction))) if n >= 3 else 0
        if n_val + n_test >= n:
            n_val, n_test = 0, 0
        split[indices[:n_val]] = "val"
        split[indices[n_val : n_val + n_test]] = "test"
    return split.astype(str)

