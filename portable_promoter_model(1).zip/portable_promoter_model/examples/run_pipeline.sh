#!/usr/bin/env bash
set -euo pipefail

# Run from portable_promoter_model/.
# Fill these paths before use.

H5AD_DIR="/path/to/h5ad_files"
EXAMPLE_H5AD="${H5AD_DIR}/example.h5ad"
GENOME_FASTA="/path/to/genome.fa"
GTF="/path/to/annotation.gtf"
GENE_ID_COLUMN="gene_id"
GENE_SYMBOL_COLUMN="gene_symbol"
GENE_SPLIT_PLAN="configs/gene_split_plan.tsv"
PANEL_DIR="outputs/gene_split_panel"
SEED=1
DEVICE="cuda:0"

python scripts/build_promoter_contexts.py \
  --h5ad "${EXAMPLE_H5AD}" \
  --gtf "${GTF}" \
  --fasta "${GENOME_FASTA}" \
  --output-dir data/processed/promoters \
  --context-radius 220 \
  --gene-id-column "${GENE_ID_COLUMN}" \
  --gene-symbol-column "${GENE_SYMBOL_COLUMN}"

python scripts/build_intergenic_contexts.py \
  --source-metadata data/processed/promoters/gene_promoters.tsv \
  --gtf "${GTF}" \
  --fasta "${GENOME_FASTA}" \
  --output-dir data/processed/intergenic \
  --context-radius 220 \
  --gene-padding 1000 \
  --seed "${SEED}"

python scripts/build_cell_index.py \
  --input-dir "${H5AD_DIR}" \
  --output-dir outputs/training_index

python scripts/build_gene_split_panels.py \
  --input-dir "${H5AD_DIR}" \
  --promoter-metadata data/processed/promoters/gene_promoters.tsv \
  --gene-split-plan "${GENE_SPLIT_PLAN}" \
  --output-dir "${PANEL_DIR}" \
  --expression-layer log_normalized \
  --n-input-features 4096 \
  --n-target-features 0 \
  --seed "${SEED}"

python scripts/train_promoter_model.py \
  --task-config configs/training/promoter_model.json \
  --input-dir "${H5AD_DIR}" \
  --index-dir outputs/training_index \
  --panel-dir "${PANEL_DIR}" \
  --promoter-dir data/processed/promoters \
  --output-dir "outputs/run_expression_seed${SEED}" \
  --mode expression_only \
  --contrastive-weight 0 \
  --seed "${SEED}" \
  --device "${DEVICE}"

python scripts/train_promoter_model.py \
  --task-config configs/training/promoter_model.json \
  --input-dir "${H5AD_DIR}" \
  --index-dir outputs/training_index \
  --panel-dir "${PANEL_DIR}" \
  --promoter-dir data/processed/promoters \
  --intergenic-dir data/processed/intergenic \
  --output-dir "outputs/run_matched_contrastive_seed${SEED}" \
  --mode expression_plus_promoter \
  --promoter-control matched \
  --contrastive-weight 0.1 \
  --seed "${SEED}" \
  --device "${DEVICE}"

python scripts/train_promoter_model.py \
  --task-config configs/training/promoter_model.json \
  --input-dir "${H5AD_DIR}" \
  --index-dir outputs/training_index \
  --panel-dir "${PANEL_DIR}" \
  --promoter-dir data/processed/promoters \
  --intergenic-dir data/processed/intergenic \
  --output-dir "outputs/run_matched_nocontrast_seed${SEED}" \
  --mode expression_plus_promoter \
  --promoter-control matched \
  --contrastive-weight 0 \
  --seed "${SEED}" \
  --device "${DEVICE}"

python scripts/train_promoter_model.py \
  --task-config configs/training/promoter_model.json \
  --input-dir "${H5AD_DIR}" \
  --index-dir outputs/training_index \
  --panel-dir "${PANEL_DIR}" \
  --promoter-dir data/processed/promoters \
  --intergenic-dir data/processed/intergenic \
  --output-dir "outputs/run_intergenic_seed${SEED}" \
  --mode expression_plus_promoter \
  --promoter-control intergenic_matched \
  --contrastive-weight 0 \
  --seed "${SEED}" \
  --device "${DEVICE}"
