#!/usr/bin/env python3
"""Shared helpers for bounded HDF5/AnnData metadata reads."""

from __future__ import annotations

from pathlib import Path
from typing import Any, Iterable

import h5py
import numpy as np
import pandas as pd


def decode_text(value: Any) -> str:
    if isinstance(value, bytes):
        return value.decode("utf-8")
    return str(value)


def decode_array(values: Iterable[Any]) -> list[str]:
    return [decode_text(value) for value in values]


def dataframe_index(group: h5py.Group) -> h5py.Dataset:
    name = decode_text(group.attrs["_index"])
    return group[name]


def column_values(node: h5py.Dataset | h5py.Group) -> np.ndarray:
    if isinstance(node, h5py.Dataset):
        values = node[:]
        if values.dtype.kind in {"S", "O"}:
            return np.asarray(decode_array(values), dtype=object)
        return values
    encoding_type = decode_text(node.attrs.get("encoding-type", ""))
    if encoding_type != "categorical":
        raise TypeError(f"unsupported encoded column: {node.name}")
    categories = node["categories"][:]
    codes = node["codes"][:]
    values = np.empty(len(codes), dtype=object)
    present = codes >= 0
    values[~present] = None
    values[present] = categories[codes[present]]
    return values


def organ_name(path: Path) -> str:
    return path.stem.split("_TSP", maxsplit=1)[0]


def normalize_object_values(values: np.ndarray) -> np.ndarray:
    normalized = []
    for value in values:
        if value is None:
            normalized.append(None)
        elif isinstance(value, bytes):
            normalized.append(value.decode("utf-8"))
        elif pd.isna(value):
            normalized.append(None)
        else:
            normalized.append(value)
    return np.asarray(normalized, dtype=object)


def read_obs_frame(path: Path, columns: list[str], allow_missing: bool = False) -> pd.DataFrame:
    with h5py.File(path, "r") as handle:
        obs = handle["obs"]
        frame = pd.DataFrame({"cell_id": decode_array(dataframe_index(obs)[:])})
        for column in columns:
            if column not in obs:
                if allow_missing:
                    frame[column] = ""
                    continue
                raise KeyError(f"missing obs column {column!r} in {path.name}")
            values = column_values(obs[column])
            if values.dtype.kind not in {"i", "u", "f", "b"}:
                values = normalize_object_values(values)
            frame[column] = values
    return frame
