#!/usr/bin/env python3
"""Shared patience-driven training loop for model-fitting scripts."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable


@dataclass(slots=True)
class TrainingRunResult:
    history: list[dict[str, object]]
    best_state: dict[str, object]
    best_epoch: int
    best_metric: float


def run_patience_training(
    *,
    train_epoch_fn: Callable[[int], float],
    evaluate_fn: Callable[[int], tuple[dict[str, float], dict[str, object]]],
    patience: int,
    max_epochs: int | None = None,
    improvement_min_delta: float = 1e-5,
    log_epoch_fn: Callable[[int, float, dict[str, float]], None] | None = None,
) -> TrainingRunResult:
    if patience <= 0:
        raise ValueError(f"patience must be positive, got {patience}")
    best_metric = float("inf")
    best_state: dict[str, object] | None = None
    best_epoch = -1
    epochs_without_improvement = 0
    history: list[dict[str, object]] = []
    epoch = 1

    while True:
        if max_epochs is not None and epoch > max_epochs:
            break

        train_sampled_mse = train_epoch_fn(epoch)
        val_metrics, candidate_best_state = evaluate_fn(epoch)

        improved = val_metrics["rmse"] < best_metric - improvement_min_delta
        if improved:
            best_metric = val_metrics["rmse"]
            best_epoch = epoch
            epochs_without_improvement = 0
            best_state = candidate_best_state
        else:
            epochs_without_improvement += 1

        epoch_record = {
            "epoch": epoch,
            "train_sampled_mse": train_sampled_mse,
            "val": val_metrics,
        }
        history.append(epoch_record)
        if log_epoch_fn is not None:
            log_epoch_fn(epoch, train_sampled_mse, val_metrics)

        if epochs_without_improvement >= patience:
            break
        epoch += 1

    if best_state is None:
        raise RuntimeError("training did not produce a best checkpoint")
    return TrainingRunResult(
        history=history,
        best_state=best_state,
        best_epoch=best_epoch,
        best_metric=best_metric,
    )
