#!/usr/bin/env python3
"""Shared helpers for portable promoter-model scripts."""

from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any



def project_root() -> Path:
    return Path(__file__).resolve().parents[1]


def scripts_dir() -> Path:
    return Path(__file__).resolve().parent


def add_repo_paths(*, include_src: bool = True, include_scripts: bool = False) -> None:
    paths = [project_root()]
    if include_src:
        paths.append(project_root() / "src")
    if include_scripts:
        paths.append(scripts_dir())
    for path in reversed(paths):
        value = str(path)
        if value not in sys.path:
            sys.path.insert(0, value)


def load_json(path: Path) -> Any:
    with path.open(encoding="utf-8") as handle:
        return json.load(handle)


def dump_json(destination: Path | Any, value: Any, *, indent: int = 2, ensure_ascii: bool = False) -> None:
    if hasattr(destination, "write"):
        json.dump(value, destination, indent=indent, ensure_ascii=ensure_ascii)
        return
    path = Path(destination)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(value, handle, indent=indent, ensure_ascii=ensure_ascii)
