#!/usr/bin/env python3
"""Shared defaults and speed settings for training scripts."""

from __future__ import annotations

import torch

TRAINING_DEFAULT_EMA_DECAY = 0.99
TRAINING_DEFAULT_PATIENCE = 16
FULL_ATLAS_DEFAULT_NUM_WORKERS = 3

# Backward-compatible aliases for promoter-specific callers.
PROMOTER_DEFAULT_EMA_DECAY = TRAINING_DEFAULT_EMA_DECAY
PROMOTER_DEFAULT_PATIENCE = TRAINING_DEFAULT_PATIENCE


def configure_torch_for_speed() -> None:
    if hasattr(torch, "set_float32_matmul_precision"):
        torch.set_float32_matmul_precision("high")
    if torch.cuda.is_available():
        torch.backends.cuda.matmul.allow_tf32 = True
        if hasattr(torch.backends.cudnn, "allow_tf32"):
            torch.backends.cudnn.allow_tf32 = True
    torch.backends.cudnn.benchmark = True
    if hasattr(torch, "use_deterministic_algorithms"):
        torch.use_deterministic_algorithms(False)
