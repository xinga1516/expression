#!/usr/bin/env python3
"""Build matched intergenic control contexts for promoter experiments."""

from __future__ import annotations

import argparse
import csv
import json
from bisect import bisect_right
from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import pandas as pd

from context_asset_utils import (
    IndexedFasta,
    context_length_for_radius,
    encode_sequence,
    reverse_complement,
    write_metadata,
)
from script_common import dump_json


@dataclass(frozen=True)
class IntervalPool:
    chrom: str
    starts: np.ndarray
    cumulative_weights: np.ndarray
    total_weight: int


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source-metadata", type=Path, required=True)
    parser.add_argument("--gtf", type=Path, required=True)
    parser.add_argument("--fasta", type=Path, required=True)
    parser.add_argument("--fai", type=Path)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--context-radius", type=int, required=True)
    parser.add_argument(
        "--gene-padding",
        type=int,
        default=1000,
        help="Padding around annotated genes excluded from intergenic sampling.",
    )
    parser.add_argument("--seed", type=int, default=1)
    return parser.parse_args(argv)


def merge_intervals(intervals: list[tuple[int, int]]) -> list[tuple[int, int]]:
    if not intervals:
        return []
    intervals = sorted(intervals)
    merged = [intervals[0]]
    for start, end in intervals[1:]:
        last_start, last_end = merged[-1]
        if start <= last_end:
            merged[-1] = (last_start, max(last_end, end))
        else:
            merged.append((start, end))
    return merged


def parse_gene_intervals(gtf_path: Path) -> dict[str, list[tuple[int, int]]]:
    intervals: dict[str, list[tuple[int, int]]] = defaultdict(list)
    with gtf_path.open() as handle:
        for line in handle:
            if line.startswith("#"):
                continue
            fields = line.rstrip("\n").split("\t")
            if len(fields) != 9 or fields[2] != "gene":
                continue
            start_0based = int(fields[3]) - 1
            end_0based = int(fields[4])
            intervals[fields[0]].append((start_0based, end_0based))
    return {chrom: merge_intervals(chrom_intervals) for chrom, chrom_intervals in intervals.items()}


def clip_interval(start: int, end: int, length: int) -> tuple[int, int] | None:
    start = max(0, start)
    end = min(length, end)
    if start >= end:
        return None
    return start, end


def build_excluded_intervals(
    gene_intervals: dict[str, list[tuple[int, int]]],
    contig_lengths: dict[str, int],
    padding: int,
) -> dict[str, list[tuple[int, int]]]:
    excluded: dict[str, list[tuple[int, int]]] = {}
    for chrom, length in contig_lengths.items():
        padded: list[tuple[int, int]] = []
        for start, end in gene_intervals.get(chrom, []):
            clipped = clip_interval(start - padding, end + padding, length)
            if clipped is not None:
                padded.append(clipped)
        excluded[chrom] = merge_intervals(padded)
    return excluded


def complement_intervals(
    length: int,
    intervals: list[tuple[int, int]],
) -> list[tuple[int, int]]:
    if not intervals:
        return [(0, length)] if length > 0 else []
    complement: list[tuple[int, int]] = []
    cursor = 0
    for start, end in intervals:
        if cursor < start:
            complement.append((cursor, start))
        cursor = max(cursor, end)
    if cursor < length:
        complement.append((cursor, length))
    return complement


def build_interval_pools(
    fasta: IndexedFasta,
    excluded: dict[str, list[tuple[int, int]]],
    context_length: int,
) -> dict[str, IntervalPool]:
    pools: dict[str, IntervalPool] = {}
    for chrom, (length, *_rest) in fasta.index.items():
        free = complement_intervals(length, excluded.get(chrom, []))
        starts = []
        weights = []
        for start, end in free:
            available = end - start - context_length + 1
            if available > 0:
                starts.append(start)
                weights.append(available)
        if starts:
            cumulative = np.cumsum(weights, dtype=np.int64)
            pools[chrom] = IntervalPool(
                chrom=chrom,
                starts=np.asarray(starts, dtype=np.int64),
                cumulative_weights=cumulative,
                total_weight=int(cumulative[-1]),
            )
    return pools


def sample_start(pool: IntervalPool, rng: np.random.Generator) -> int:
    if pool.total_weight <= 0:
        raise ValueError("interval pool is empty")
    pick = int(rng.integers(pool.total_weight))
    idx = bisect_right(pool.cumulative_weights, pick)
    interval_start = int(pool.starts[idx])
    previous_weight = int(pool.cumulative_weights[idx - 1]) if idx > 0 else 0
    offset = pick - previous_weight
    return interval_start + offset


def sample_pool(pools: dict[str, IntervalPool], rng: np.random.Generator) -> IntervalPool:
    if not pools:
        raise ValueError("no interval pools available")
    pool_list = list(pools.values())
    cumulative = np.cumsum([pool.total_weight for pool in pool_list], dtype=np.int64)
    pick = int(rng.integers(int(cumulative[-1])))
    idx = bisect_right(cumulative, pick)
    return pool_list[idx]


def main(argv: list[str] | None = None) -> None:
    args = parse_args(argv)
    args.output_dir.mkdir(parents=True, exist_ok=True)
    fai_path = args.fai or Path(f"{args.fasta}.fai")
    context_radius = args.context_radius
    if context_radius <= 0:
        raise ValueError(f"context radius must be positive, got {context_radius}")
    if args.gene_padding < 0:
        raise ValueError(f"gene padding must be non-negative, got {args.gene_padding}")
    context_length = 2 * context_radius + 1

    source_metadata = pd.read_csv(args.source_metadata, sep="\t").sort_values(
        "feature_index"
    ).reset_index(drop=True)
    if "chrom" not in source_metadata or "strand" not in source_metadata:
        raise ValueError("source metadata must contain chrom and strand columns")

    source_metadata = source_metadata.rename(columns={"status": "source_status"})
    source_metadata["source_gene_id"] = source_metadata["gene_id"].astype(str)

    fasta = IndexedFasta(args.fasta, fai_path)
    gene_intervals = parse_gene_intervals(args.gtf)
    excluded = build_excluded_intervals(
        gene_intervals,
        {chrom: length for chrom, (length, *_rest) in fasta.index.items()},
        args.gene_padding,
    )
    chrom_pools = build_interval_pools(fasta, excluded, context_length)
    rng = np.random.default_rng(args.seed)

    contexts: list[np.ndarray] = []
    metadata: list[dict[str, object]] = []
    status_counts: dict[str, int] = {}
    source_status_counts: dict[str, int] = {}
    try:
        for row in source_metadata.to_dict(orient="records"):
            source_status = str(row.get("source_status", ""))
            source_chrom = str(row.get("chrom", ""))
            source_strand = str(row.get("strand", ""))
            output = dict(row)
            output.update(
                {
                    "context_row": -1,
                    "status": "",
                    "selected_chrom": "",
                    "selected_start_0based": "",
                    "selected_end_0based_exclusive": "",
                    "n_fraction": "",
                    "sequence_qc": "",
                }
            )
            source_status_counts[source_status] = source_status_counts.get(source_status, 0) + 1

            if source_status != "ok":
                status = "source_not_ok"
            elif source_chrom not in fasta.index:
                status = "contig_not_in_fasta"
            else:
                pool = chrom_pools.get(source_chrom)
                fallback = False
                if pool is None:
                    pool = sample_pool(chrom_pools, rng) if chrom_pools else None
                    fallback = pool is not None
                if pool is None:
                    status = "no_intergenic_window"
                else:
                    start = sample_start(pool, rng)
                    end = start + context_length
                    sequence = fasta.fetch(pool.chrom, start, end)
                    if source_strand == "-":
                        sequence = reverse_complement(sequence)
                    encoded = encode_sequence(sequence)
                    if encoded.shape != (context_length,):
                        raise RuntimeError(
                            f"unexpected sequence length for feature_index={row['feature_index']}"
                        )
                    context_row = len(contexts)
                    contexts.append(encoded)
                    status = "ok" if not fallback else "ok_fallback_chrom"
                    output.update(
                        {
                            "context_row": context_row,
                            "selected_chrom": pool.chrom,
                            "selected_start_0based": start,
                            "selected_end_0based_exclusive": end,
                            "n_fraction": float(np.mean(encoded == 4)),
                            "sequence_qc": "contains_N" if np.any(encoded == 4) else "pass",
                        }
                    )
            output["status"] = status
            status_counts[status] = status_counts.get(status, 0) + 1
            metadata.append(output)
    finally:
        fasta.close()

    if not contexts:
        raise RuntimeError("no intergenic contexts were generated")

    context_array = np.stack(contexts).astype(np.uint8, copy=False)
    np.save(args.output_dir / "intergenic_contexts.uint8.npy", context_array)
    write_metadata(args.output_dir / "gene_intergenic.tsv", metadata)

    summary = {
        "source_metadata": str(args.source_metadata.resolve()),
        "gtf": str(args.gtf.resolve()),
        "fasta": str(args.fasta.resolve()),
        "context_definition": {
            "length": context_length,
            "tss_index": context_radius,
            "transcription_oriented": True,
            "training_slice_length": context_length,
            "training_shift_min": 0,
            "training_shift_max": 0,
        },
        "gene_padding": args.gene_padding,
        "n_source_rows": int(len(source_metadata)),
        "n_contexts": int(len(contexts)),
        "status_counts": status_counts,
        "source_status_counts": source_status_counts,
        "sequence_qc_counts": {
            "pass": sum(row["sequence_qc"] == "pass" for row in metadata),
            "contains_N": sum(row["sequence_qc"] == "contains_N" for row in metadata),
        },
        "codebook": {"A": 0, "C": 1, "G": 2, "T": 3, "N_or_other": 4},
    }
    dump_json(args.output_dir / "summary.json", summary, indent=2)


if __name__ == "__main__":
    main()
