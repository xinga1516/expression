#!/usr/bin/env python3
"""Build a scalable on-disk cell index for promoter-model training."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Iterable

import h5py

from atlas_io import column_values, decode_array, decode_text, dataframe_index, normalize_object_values, organ_name, read_obs_frame
from script_common import dump_json
import numpy as np
import pandas as pd


class AtlasExpressionReader:
    def __init__(self, input_dir: Path, feature_lookup: np.ndarray, n_features: int, expression_layer: str) -> None:
        self.input_dir = Path(input_dir)
        self.feature_lookup = np.asarray(feature_lookup, dtype=np.int32)
        self.n_features = int(n_features)
        self.expression_layer = expression_layer
        if self.feature_lookup.shape != (self.n_features,):
            raise ValueError(
                f"feature_lookup must have shape ({self.n_features},), got {self.feature_lookup.shape}"
            )
        valid = self.feature_lookup[self.feature_lookup >= 0]
        self.union_feature_count = int(valid.max() + 1) if valid.size else 0
        self._handles: dict[str, h5py.File] = {}

    def _handle(self, source_file: str) -> h5py.File:
        handle = self._handles.get(source_file)
        if handle is None:
            handle = h5py.File(self.input_dir / source_file, 'r')
            self._handles[source_file] = handle
        return handle

    def read_dense_rows(self, source_file: str, rows: np.ndarray) -> np.ndarray:
        rows = np.asarray(rows, dtype=np.int64)
        if rows.ndim != 1:
            raise ValueError('rows must be one-dimensional')
        if rows.size == 0:
            return np.zeros((0, self.union_feature_count), dtype=np.float32)

        handle = self._handle(source_file)
        layer = handle['layers'][self.expression_layer]
        if not isinstance(layer, h5py.Group):
            raise TypeError(f'unsupported layer layout for {source_file!r}: {type(layer)!r}')
        data = layer['data']
        indices = layer['indices']
        indptr = layer['indptr']
        n_rows = int(layer.attrs['shape'][0])
        if np.any((rows < 0) | (rows >= n_rows)):
            raise IndexError(f'row index out of bounds for {source_file!r}')

        result = np.zeros((rows.size, self.union_feature_count), dtype=np.float32)
        for out_row, row in enumerate(rows):
            start = int(indptr[row])
            end = int(indptr[row + 1])
            row_features = indices[start:end]
            mapped = self.feature_lookup[row_features]
            present = mapped >= 0
            if np.any(present):
                result[out_row, mapped[present]] = data[start:end][present].astype(np.float32, copy=False)
        return result

    def close(self) -> None:
        for handle in self._handles.values():
            handle.close()
        self._handles.clear()


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input-dir", type=Path, required=True)
    parser.add_argument("--gene-manifest", type=Path)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--pattern", default="*.h5ad")
    return parser.parse_args()


def build_cell_index_frame(
    *,
    organ: str,
    source_file: str,
    obs: pd.DataFrame,
    global_start: int,
) -> pd.DataFrame:
    frame = obs.copy().reset_index(drop=True)
    frame.insert(0, "global_cell_index", np.arange(global_start, global_start + len(frame), dtype=np.int64))
    frame.insert(1, "organ", organ)
    frame.insert(2, "source_file", source_file)
    frame.insert(3, "source_row", np.arange(len(frame), dtype=np.int64))

    ordered_columns = [
        "global_cell_index",
        "organ",
        "source_file",
        "source_row",
        "cell_id",
        "donor",
        "sample_id",
        "cell_ontology_class",
        "broad_cell_class",
        "n_genes_by_counts",
        "total_counts",
        "pct_counts_mt",
        "age",
        "sex",
    ]
    missing = [column for column in ordered_columns if column not in frame.columns]
    if missing:
        raise KeyError(f"cell frame missing columns: {missing}")
    return frame[ordered_columns].copy()


def summarize_cells(frame: pd.DataFrame) -> dict[str, object]:
    summary = {
        "n_cells": int(len(frame)),
    }
    return summary


def main() -> None:
    args = parse_args()
    gene_manifest = pd.read_csv(args.gene_manifest, sep="\t") if args.gene_manifest else None

    cell_columns = [
        "donor",
        "sample_id",
        "cell_ontology_class",
        "broad_cell_class",
        "n_genes_by_counts",
        "total_counts",
        "pct_counts_mt",
        "age",
        "sex",
    ]

    files = sorted(args.input_dir.glob(args.pattern))
    if not files:
        raise FileNotFoundError(f"no files matched {args.pattern!r} in {args.input_dir}")

    cells_dir = args.output_dir / "cells"
    cells_dir.mkdir(parents=True, exist_ok=True)
    args.output_dir.mkdir(parents=True, exist_ok=True)

    manifest_rows = []
    global_start = 0

    for index, path in enumerate(files, start=1):
        organ = organ_name(path)
        print(f"[{index}/{len(files)}] {organ}: {path.name}", flush=True)
        obs = read_obs_frame(path, cell_columns, allow_missing=True)
        frame = build_cell_index_frame(
            organ=organ,
            source_file=path.name,
            obs=obs,
            global_start=global_start,
        )
        shard_path = cells_dir / f"{organ}.tsv.gz"
        frame.to_csv(shard_path, sep="	", index=False, compression="gzip")
        summary = summarize_cells(frame)
        summary.update(
            {
                "organ": organ,
                "source_file": path.name,
                "shard_path": str(shard_path.relative_to(args.output_dir)),
            }
        )
        manifest_rows.append(summary)
        global_start += len(frame)

    cells_manifest = pd.DataFrame(manifest_rows)
    cells_manifest.to_csv(args.output_dir / "cells_manifest.tsv", sep="	", index=False)
    if gene_manifest is not None:
        gene_manifest.to_csv(args.output_dir / "genes.tsv", sep="\t", index=False)

    summary = {
        "run_id": "cell_index_v1",
        "n_files": len(files),
        "n_cells": int(cells_manifest["n_cells"].sum()),
        "source_input_dir": str(args.input_dir.resolve()),
        "gene_manifest": str(Path(args.gene_manifest).resolve()) if args.gene_manifest else "",
        "cell_manifest": str((args.output_dir / "cells_manifest.tsv").resolve()),
        "gene_rows": int(len(gene_manifest)) if gene_manifest is not None else 0,
        "cell_shards_dir": str(cells_dir.resolve()),
        "organ_cell_counts": {row["organ"]: int(row["n_cells"]) for _, row in cells_manifest.iterrows()},
        "cell_pool_policy": "all_cells",
    }
    with (args.output_dir / "summary.json").open("w", encoding="utf-8") as handle:
        dump_json(handle, summary, indent=2)
        handle.write("\n")


if __name__ == "__main__":
    main()
