#!/usr/bin/env python3
"""Build strand-oriented promoter contexts for h5ad genes."""

from __future__ import annotations

import argparse
import csv
import json
import re
from dataclasses import dataclass
from pathlib import Path

from script_common import dump_json
from typing import Iterable

import anndata as ad
import numpy as np


DNA_TO_CODE = np.full(256, 4, dtype=np.uint8)
for base, code in zip(b"ACGT", range(4), strict=True):
    DNA_TO_CODE[base] = code
    DNA_TO_CODE[base + 32] = code


def strip_version(identifier: str) -> str:
    return identifier.rsplit(".", 1)[0]


def parse_attributes(text: str) -> dict[str, list[str]]:
    attributes: dict[str, list[str]] = {}
    for key, value in re.findall(r'(\S+) "([^"]*)";', text):
        attributes.setdefault(key, []).append(value)
    return attributes


@dataclass(frozen=True)
class Transcript:
    gene_id: str
    gene_id_versioned: str
    gene_name: str
    gene_type: str
    transcript_id: str
    transcript_type: str
    chrom: str
    start_1based: int
    end_1based: int
    strand: str
    tags: tuple[str, ...]
    selection_rule: str

    @property
    def tss_1based(self) -> int:
        return self.start_1based if self.strand == "+" else self.end_1based


class IndexedFasta:
    def __init__(self, fasta_path: Path, fai_path: Path) -> None:
        self.handle = fasta_path.open("rb")
        self.index: dict[str, tuple[int, int, int, int]] = {}
        with fai_path.open() as handle:
            for line in handle:
                name, length, offset, line_bases, line_width, *_ = line.split(
                    "\t"
                )
                self.index[name] = (
                    int(length),
                    int(offset),
                    int(line_bases),
                    int(line_width),
                )

    def close(self) -> None:
        self.handle.close()

    def fetch(self, chrom: str, start: int, end: int) -> str:
        """Fetch a 0-based half-open interval."""
        length, offset, line_bases, line_width = self.index[chrom]
        if start < 0 or end > length or start >= end:
            raise ValueError(f"out-of-bounds interval: {chrom}:{start}-{end}")

        chunks = []
        position = start
        while position < end:
            line_offset = position % line_bases
            take = min(end - position, line_bases - line_offset)
            byte_offset = (
                offset
                + (position // line_bases) * line_width
                + line_offset
            )
            self.handle.seek(byte_offset)
            chunks.append(self.handle.read(take))
            position += take
        return b"".join(chunks).decode("ascii")


def reverse_complement(sequence: str) -> str:
    return sequence.translate(str.maketrans("ACGTNacgtn", "TGCANtgcan"))[::-1]


def select_transcripts(
    gtf_path: Path, target_gene_ids: set[str]
) -> tuple[dict[str, Transcript], set[str]]:
    selected: dict[str, Transcript] = {}
    genes_in_gtf: set[str] = set()
    priorities = {"MANE_Select": 0, "Ensembl_canonical": 1}

    with gtf_path.open() as handle:
        for line in handle:
            if line.startswith("#"):
                continue
            fields = line.rstrip("\n").split("\t")
            if len(fields) != 9 or fields[2] not in {"gene", "transcript"}:
                continue
            attributes = parse_attributes(fields[8])
            gene_id_versioned = attributes["gene_id"][0]
            gene_id = strip_version(gene_id_versioned)
            if gene_id not in target_gene_ids:
                continue
            genes_in_gtf.add(gene_id)
            if fields[2] != "transcript":
                continue

            tags = tuple(attributes.get("tag", []))
            matching = [tag for tag in priorities if tag in tags]
            selection_rule = min(matching, key=priorities.__getitem__) if matching else "longest_transcript_fallback"
            transcript = Transcript(
                gene_id=gene_id,
                gene_id_versioned=gene_id_versioned,
                gene_name=attributes.get("gene_name", [""])[0],
                gene_type=attributes.get("gene_type", [""])[0],
                transcript_id=attributes["transcript_id"][0],
                transcript_type=attributes.get("transcript_type", [""])[0],
                chrom=fields[0],
                start_1based=int(fields[3]),
                end_1based=int(fields[4]),
                strand=fields[6],
                tags=tags,
                selection_rule=selection_rule,
            )

            current = selected.get(gene_id)
            current_priority = priorities.get(current.selection_rule, 99) if current is not None else 999
            candidate_priority = priorities.get(selection_rule, 99)
            transcript_length = transcript.end_1based - transcript.start_1based + 1
            current_length = (
                current.end_1based - current.start_1based + 1 if current is not None else -1
            )
            candidate_key = (candidate_priority, -transcript_length, transcript.transcript_id)
            current_key = (
                current_priority,
                -current_length,
                current.transcript_id if current is not None else "",
            )
            if current is None or candidate_key < current_key:
                selected[gene_id] = transcript
    return selected, genes_in_gtf


def encode_sequence(sequence: str) -> np.ndarray:
    raw = np.frombuffer(sequence.encode("ascii"), dtype=np.uint8)
    return DNA_TO_CODE[raw]


def context_length_for_radius(radius: int) -> int:
    if radius < 0:
        raise ValueError(f"context radius must be non-negative, got {radius}")
    return 2 * radius + 1


def extract_context(
    fasta: IndexedFasta, transcript: Transcript, context_radius: int
) -> tuple[str, int, int]:
    """Extract a centered context with downstream on the right."""
    tss0 = transcript.tss_1based - 1
    start = tss0 - context_radius
    end = tss0 + context_radius + 1
    sequence = fasta.fetch(transcript.chrom, start, end)
    if transcript.strand == "-":
        sequence = reverse_complement(sequence)
    return sequence, start, end


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--h5ad", type=Path, required=True)
    parser.add_argument("--gtf", type=Path, required=True)
    parser.add_argument("--fasta", type=Path, required=True)
    parser.add_argument("--fai", type=Path)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--context-radius", type=int, required=True)
    parser.add_argument("--gene-id-column", default="ensembl_id")
    parser.add_argument("--gene-symbol-column", default="gene_symbol")
    return parser.parse_args(argv)


def write_metadata(path: Path, rows: Iterable[dict[str, object]]) -> None:
    rows = list(rows)
    with path.open("w", newline="") as handle:
        writer = csv.DictWriter(
            handle, fieldnames=list(rows[0]), delimiter="\t"
        )
        writer.writeheader()
        writer.writerows(rows)


def main(argv: list[str] | None = None) -> None:
    args = parse_args(argv)
    args.output_dir.mkdir(parents=True, exist_ok=True)
    fai_path = args.fai or Path(f"{args.fasta}.fai")
    context_radius = args.context_radius
    if context_radius <= 0:
        raise ValueError(f"context radius must be positive, got {context_radius}")
    context_length = context_length_for_radius(context_radius)

    adata = ad.read_h5ad(args.h5ad, backed="r")
    try:
        if args.gene_id_column not in adata.var:
            raise KeyError(f"missing var gene id column: {args.gene_id_column!r}")
        if args.gene_symbol_column not in adata.var:
            raise KeyError(f"missing var gene symbol column: {args.gene_symbol_column!r}")
        feature_rows = [
            {
                "feature_index": index,
                "var_name": str(var_name),
                "input_gene_id_raw": str(ensembl_id),
                "gene_id": strip_version(str(ensembl_id)),
                "input_gene_symbol": str(gene_symbol),
            }
            for index, (var_name, ensembl_id, gene_symbol) in enumerate(
                zip(
                    adata.var_names,
                    adata.var[args.gene_id_column],
                    adata.var[args.gene_symbol_column],
                    strict=True,
                )
            )
        ]
    finally:
        adata.file.close()

    target_gene_ids = {row["gene_id"] for row in feature_rows}
    transcripts, genes_in_gtf = select_transcripts(args.gtf, target_gene_ids)
    fasta = IndexedFasta(args.fasta, fai_path)

    contexts = []
    metadata = []
    status_counts: dict[str, int] = {}
    selection_counts: dict[str, int] = {}
    try:
        for row in feature_rows:
            gene_id = str(row["gene_id"])
            transcript = transcripts.get(gene_id)
            output = dict(row)
            output.update(
                {
                    "context_row": -1,
                    "status": "",
                    "selection_rule": "",
                    "selected_gene_id": "",
                    "selected_gene_name": "",
                    "gene_type": "",
                    "transcript_id": "",
                    "transcript_type": "",
                    "chrom": "",
                    "strand": "",
                    "tss_1based": "",
                    "context_start_0based": "",
                    "context_end_0based_exclusive": "",
                    "n_fraction": "",
                    "sequence_qc": "",
                }
            )

            if gene_id not in genes_in_gtf:
                status = "gene_absent_from_gtf"
            elif transcript is None:
                status = "no_selected_transcript"
            elif transcript.chrom not in fasta.index:
                status = "contig_not_in_fasta"
            else:
                tss0 = transcript.tss_1based - 1
                start = tss0 - context_radius
                end = tss0 + context_radius + 1
                contig_length = fasta.index[transcript.chrom][0]
                if start < 0 or end > contig_length:
                    status = "context_out_of_bounds"
                else:
                    sequence, start, end = extract_context(fasta, transcript, context_radius)
                    encoded = encode_sequence(sequence)
                    if encoded.shape != (context_length,):
                        raise RuntimeError(
                            f"unexpected sequence length for {gene_id}"
                        )
                    context_row = len(contexts)
                    contexts.append(encoded)
                    status = "ok"
                    output.update(
                        {
                            "context_row": context_row,
                            "selection_rule": transcript.selection_rule,
                            "selected_gene_id": transcript.gene_id_versioned,
                            "selected_gene_name": transcript.gene_name,
                            "gene_type": transcript.gene_type,
                            "transcript_id": transcript.transcript_id,
                            "transcript_type": transcript.transcript_type,
                            "chrom": transcript.chrom,
                            "strand": transcript.strand,
                            "tss_1based": transcript.tss_1based,
                            "context_start_0based": start,
                            "context_end_0based_exclusive": end,
                            "n_fraction": float(np.mean(encoded == 4)),
                            "sequence_qc": (
                                "contains_N" if np.any(encoded == 4) else "pass"
                            ),
                        }
                    )
                    selection_counts[transcript.selection_rule] = (
                        selection_counts.get(transcript.selection_rule, 0) + 1
                    )

            output["status"] = status
            status_counts[status] = status_counts.get(status, 0) + 1
            metadata.append(output)
    finally:
        fasta.close()

    context_array = np.stack(contexts).astype(np.uint8, copy=False)
    np.save(args.output_dir / "promoter_contexts.uint8.npy", context_array)
    write_metadata(args.output_dir / "gene_promoters.tsv", metadata)

    summary = {
        "h5ad": str(args.h5ad.resolve()),
        "gtf": str(args.gtf.resolve()),
        "fasta": str(args.fasta.resolve()),
        "context_definition": {
            "length": context_length,
            "tss_index": context_radius,
            "transcription_oriented": True,
            "training_slice_length": context_length,
            "training_shift_min": 0,
            "training_shift_max": 0,
        },
        "n_input_features": len(feature_rows),
        "n_contexts": len(contexts),
        "status_counts": status_counts,
        "selection_counts": selection_counts,
        "sequence_qc_counts": {
            "pass": sum(row["sequence_qc"] == "pass" for row in metadata),
            "contains_N": sum(
                row["sequence_qc"] == "contains_N" for row in metadata
            ),
        },
        "codebook": {"A": 0, "C": 1, "G": 2, "T": 3, "N_or_other": 4},
    }
    dump_json(args.output_dir / "summary.json", summary, indent=2)


if __name__ == "__main__":
    main()
