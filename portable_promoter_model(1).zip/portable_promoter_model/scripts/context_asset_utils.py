#!/usr/bin/env python3
"""Shared helpers for promoter and intergenic context assets."""

from __future__ import annotations

import csv
import re
from pathlib import Path

import numpy as np


DNA_TO_CODE = np.full(256, 4, dtype=np.uint8)
for base, code in zip(b"ACGT", range(4), strict=True):
    DNA_TO_CODE[base] = code
    DNA_TO_CODE[base + 32] = code


def strip_version(identifier: str) -> str:
    return identifier.rsplit(".", 1)[0]


def parse_attributes(text: str) -> dict[str, list[str]]:
    attributes: dict[str, list[str]] = {}
    for key, value in re.findall(r'(\S+) "([^"]*)";', text):
        attributes.setdefault(key, []).append(value)
    return attributes


class IndexedFasta:
    def __init__(self, fasta_path: Path, fai_path: Path) -> None:
        self.handle = fasta_path.open("rb")
        self.index: dict[str, tuple[int, int, int, int]] = {}
        with fai_path.open() as handle:
            for line in handle:
                name, length, offset, line_bases, line_width, *_ = line.split("	")
                self.index[name] = (
                    int(length),
                    int(offset),
                    int(line_bases),
                    int(line_width),
                )

    def close(self) -> None:
        self.handle.close()

    def fetch(self, chrom: str, start: int, end: int) -> str:
        length, offset, line_bases, line_width = self.index[chrom]
        if start < 0 or end > length or start >= end:
            raise ValueError(f"out-of-bounds interval: {chrom}:{start}-{end}")

        chunks = []
        position = start
        while position < end:
            line_offset = position % line_bases
            take = min(end - position, line_bases - line_offset)
            byte_offset = offset + (position // line_bases) * line_width + line_offset
            self.handle.seek(byte_offset)
            chunks.append(self.handle.read(take))
            position += take
        return b"".join(chunks).decode("ascii")


def reverse_complement(sequence: str) -> str:
    return sequence.translate(str.maketrans("ACGTNacgtn", "TGCANtgcan"))[::-1]


def encode_sequence(sequence: str) -> np.ndarray:
    raw = np.frombuffer(sequence.encode("ascii"), dtype=np.uint8)
    return DNA_TO_CODE[raw]


def context_length_for_radius(radius: int) -> int:
    if radius < 0:
        raise ValueError(f"context radius must be non-negative, got {radius}")
    return 2 * radius + 1


def write_metadata(path: Path, rows: list[dict[str, object]] | tuple[dict[str, object], ...] | list[dict[str, object]] | object) -> None:
    rows = list(rows)
    if not rows:
        raise ValueError("metadata is empty")
    with path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]), delimiter="	")
        writer.writeheader()
        writer.writerows(rows)
