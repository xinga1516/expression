#!/usr/bin/env python3
"""Full-atlas promoter-aware training framework."""

from __future__ import annotations

import argparse
import copy
import random
import time
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

import h5py
import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F
from torch import nn

from script_common import add_repo_paths, dump_json
from training_config import default_training_config_path, load_training_config
from training_engine import run_patience_training

add_repo_paths(include_src=True, include_scripts=True)

from promoter_model.promoters import sample_shifts
from build_cell_index import AtlasExpressionReader
from training_common import (
    FULL_ATLAS_DEFAULT_NUM_WORKERS,
    TRAINING_DEFAULT_EMA_DECAY,
    TRAINING_DEFAULT_PATIENCE,
    configure_torch_for_speed,
)
from model_components import (
    ExponentialMovingAverage,
    PromoterExpressionModel,
    build_control_contexts,
    load_intergenic_contexts,
    mask_batch,
    normalize_gene_split,
    promoter_batch,
    regression_metrics,
)

DEFAULT_TRAINING_CONFIG_PATH = default_training_config_path("promoter_model")

CELL_INDEX_COLUMNS = [
    "global_cell_index",
    "organ",
    "source_file",
    "source_row",
]


def parse_args() -> argparse.Namespace:
    pre_parser = argparse.ArgumentParser(add_help=False)
    pre_parser.add_argument(
        "--task-config",
        type=Path,
        default=DEFAULT_TRAINING_CONFIG_PATH,
    )
    pre_args, _ = pre_parser.parse_known_args()
    defaults = load_training_config(pre_args.task_config)

    parser = argparse.ArgumentParser(parents=[pre_parser])
    parser.add_argument("--input-dir", type=Path, required=True)
    parser.add_argument("--index-dir", type=Path, required=True)
    parser.add_argument("--panel-dir", type=Path, required=True)
    parser.add_argument("--promoter-dir", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--pattern", default="*.h5ad")
    parser.add_argument("--expression-layer", default="log_normalized")
    parser.add_argument(
        "--mode",
        choices=("expression_only", "expression_plus_promoter"),
        default="expression_plus_promoter",
    )
    parser.add_argument(
        "--promoter-control",
        choices=("matched", "intergenic_matched"),
        default="matched",
    )
    parser.add_argument(
        "--promoter-encoder",
        choices=("cnn_pool", "cnn_bilstm"),
        default="cnn_bilstm",
    )
    parser.add_argument(
        "--promoter-radius",
        type=int,
        default=200,
    )
    parser.add_argument(
        "--ema-decay",
        type=float,
        default=TRAINING_DEFAULT_EMA_DECAY,
        help="EMA checkpoint decay; defaults to 0.99 (enabled).",
    )
    parser.add_argument("--intergenic-dir", type=Path)
    parser.add_argument(
        "--contrastive-weight",
        type=float,
        default=0.0,
        help="Optional auxiliary triplet-loss weight for promoter vs intergenic contrastive learning.",
    )
    parser.add_argument(
        "--contrastive-margin",
        type=float,
        default=0.5,
        help="Triplet margin for auxiliary promoter/intergenic contrastive learning.",
    )
    parser.add_argument("--device", default="cpu")
    parser.add_argument("--seed", type=int, default=1)
    parser.add_argument(
        "--epochs",
        type=int,
        default=None,
        help="Optional hard epoch cap for debugging; default is validation patience only.",
    )
    parser.add_argument("--patience", type=int, default=TRAINING_DEFAULT_PATIENCE)
    parser.add_argument("--num-workers", type=int, default=FULL_ATLAS_DEFAULT_NUM_WORKERS)
    parser.add_argument("--cell-batch-size", type=int, default=64)
    parser.add_argument("--pair-batch-size", type=int, default=512)
    parser.add_argument("--targets-per-cell", type=int, default=8)
    parser.add_argument("--learning-rate", type=float, default=1e-3)
    parser.add_argument("--weight-decay", type=float, default=1e-5)
    parser.add_argument("--max-train-cells-per-epoch", type=int, default=8192)
    parser.add_argument("--validation-cells", type=int, default=2048)
    parser.add_argument("--test-cells", type=int, default=2048)
    parser.set_defaults(**defaults)
    args = parser.parse_args()
    if isinstance(args.intergenic_dir, str) and args.intergenic_dir:
        args.intergenic_dir = Path(args.intergenic_dir)
    return args


def seed_everything(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    configure_torch_for_speed()
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def load_tsv(path: Path) -> pd.DataFrame:
    return pd.read_csv(path, sep="\t")




def read_cell_index(index_dir: Path) -> pd.DataFrame:
    cells_dir = index_dir / "cells"
    files = sorted(cells_dir.glob("*.tsv.gz"))
    if not files:
        raise FileNotFoundError(f"no cell shards found under {cells_dir}")
    frames = []
    for path in files:
        frame = pd.read_csv(path, sep="\t", compression="gzip", usecols=CELL_INDEX_COLUMNS)
        frames.append(frame)
    cells = pd.concat(frames, ignore_index=True)
    return cells


def load_panel_tables(panel_dir: Path, promoter_dir: Path) -> tuple[pd.DataFrame, pd.DataFrame]:
    input_panel = load_tsv(panel_dir / "input_features.tsv").sort_values("input_position").reset_index(drop=True)
    target_panel = load_tsv(panel_dir / "target_genes.tsv").sort_values("target_index").reset_index(drop=True)
    promoters = load_tsv(promoter_dir / "gene_promoters.tsv")[["feature_index", "context_row"]]
    target_panel = target_panel.merge(promoters, on="feature_index", how="left", validate="one_to_one")
    if target_panel["context_row"].isna().any():
        missing = target_panel.loc[target_panel["context_row"].isna(), "gene_id"].head(10).tolist()
        raise ValueError(f"missing promoter contexts for targets: {missing}")
    target_panel["context_row"] = target_panel["context_row"].astype(np.int64)
    return input_panel, target_panel


def build_feature_lookups(
    n_features: int,
    input_panel: pd.DataFrame,
    target_panel: pd.DataFrame,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    input_feature_indices = input_panel["feature_index"].to_numpy(dtype=np.int64)
    target_feature_indices = target_panel["feature_index"].to_numpy(dtype=np.int64)
    union_feature_indices = np.unique(np.concatenate([input_feature_indices, target_feature_indices]))
    if union_feature_indices.size == 0:
        raise ValueError("empty panel union")
    if int(union_feature_indices.max()) >= n_features:
        raise ValueError("panel feature index exceeds matrix width")

    union_lookup = np.full(n_features, -1, dtype=np.int32)
    union_lookup[union_feature_indices] = np.arange(union_feature_indices.size, dtype=np.int32)
    input_union_columns = union_lookup[input_feature_indices]
    target_union_columns = union_lookup[target_feature_indices]
    if np.any(input_union_columns < 0) or np.any(target_union_columns < 0):
        raise ValueError("failed to build panel lookup tables")
    return union_feature_indices, union_lookup, input_union_columns, target_union_columns, target_feature_indices


def sample_frame(frame: pd.DataFrame, n: int, seed: int) -> pd.DataFrame:
    if len(frame) <= n:
        return frame.sort_values("global_cell_index").reset_index(drop=True)
    return frame.sample(n=n, random_state=seed).sort_values("global_cell_index").reset_index(drop=True)


def build_cell_batches(frame: pd.DataFrame, batch_size: int) -> list[pd.DataFrame]:
    batches = []
    frame = frame.sort_values(["source_file", "source_row"]).reset_index(drop=True)
    for start in range(0, len(frame), batch_size):
        batches.append(frame.iloc[start:start + batch_size].copy())
    return batches


def materialize_batch_matrices(
    reader: AtlasExpressionReader,
    batch_frame: pd.DataFrame,
    input_union_columns: np.ndarray,
    target_union_columns: np.ndarray,
) -> tuple[np.ndarray, np.ndarray]:
    batch_frame = batch_frame.sort_values(["source_file", "source_row"]).reset_index(drop=True)
    input_parts = []
    target_parts = []
    for source_file, group in batch_frame.groupby("source_file", sort=False):
        rows = group["source_row"].to_numpy(dtype=np.int64)
        union_dense = reader.read_dense_rows(source_file, rows)
        input_parts.append(union_dense[:, input_union_columns])
        target_parts.append(union_dense[:, target_union_columns])
    input_matrix = np.concatenate(input_parts, axis=0) if input_parts else np.zeros((0, len(input_union_columns)), dtype=np.float32)
    target_matrix = np.concatenate(target_parts, axis=0) if target_parts else np.zeros((0, len(target_union_columns)), dtype=np.float32)
    return input_matrix, target_matrix


_BATCH_WORKER_STATE: dict[str, object] | None = None


def _init_batch_worker(
    input_dir: Path,
    feature_lookup: np.ndarray,
    n_features: int,
    expression_layer: str,
    input_union_columns: np.ndarray,
    target_union_columns: np.ndarray,
) -> None:
    global _BATCH_WORKER_STATE
    _BATCH_WORKER_STATE = {
        "reader": AtlasExpressionReader(input_dir, feature_lookup, n_features, expression_layer),
        "input_union_columns": input_union_columns,
        "target_union_columns": target_union_columns,
    }


def _materialize_batch_job(batch_frame: pd.DataFrame) -> tuple[np.ndarray, np.ndarray]:
    if _BATCH_WORKER_STATE is None:
        raise RuntimeError("batch worker state not initialized")
    reader = _BATCH_WORKER_STATE["reader"]
    return materialize_batch_matrices(
        reader,
        batch_frame,
        _BATCH_WORKER_STATE["input_union_columns"],
        _BATCH_WORKER_STATE["target_union_columns"],
    )


def iter_materialized_batches(
    batch_frames: list[pd.DataFrame],
    reader: AtlasExpressionReader,
    input_union_columns: np.ndarray,
    target_union_columns: np.ndarray,
    batch_executor: ProcessPoolExecutor | None,
) -> tuple[np.ndarray, np.ndarray] | list[tuple[np.ndarray, np.ndarray]] | object:
    if batch_executor is None:
        for batch_frame in batch_frames:
            yield materialize_batch_matrices(reader, batch_frame, input_union_columns, target_union_columns)
        return
    yield from batch_executor.map(_materialize_batch_job, batch_frames, chunksize=1)


@torch.no_grad()
def evaluate_split(
    model: PromoterExpressionModel,
    reader: AtlasExpressionReader,
    cells: pd.DataFrame,
    gene_indices: np.ndarray,
    target_input_positions: torch.Tensor,
    contexts: np.ndarray,
    target_context_rows: np.ndarray,
    input_union_columns: np.ndarray,
    target_union_columns: np.ndarray,
    batch_executor: ProcessPoolExecutor | None,
    args: argparse.Namespace,
    device: torch.device,
) -> tuple[dict[str, float], np.ndarray]:
    model.eval()
    if len(cells) == 0 or len(gene_indices) == 0:
        empty = np.zeros((len(cells), len(gene_indices)), dtype=np.float32)
        return {
            "rmse": float("nan"),
            "mae": float("nan"),
            "pearson_all_values": float("nan"),
            "median_per_gene_pearson": float("nan"),
            "n_genes_with_defined_pearson": 0,
            "zero_fraction": float("nan"),
            "positive_fraction": float("nan"),
            "nonzero_rmse": float("nan"),
            "nonzero_mae": float("nan"),
            "zero_rmse": float("nan"),
            "zero_mae": float("nan"),
            "pred_positive_rate_at_zero": float("nan"),
            "expressed_auroc": float("nan"),
            "expressed_average_precision": float("nan"),
            "top_expression_decile_rmse": float("nan"),
        }, empty

    predictions = np.empty(len(cells) * len(gene_indices), dtype=np.float32)
    truths = np.empty(len(cells) * len(gene_indices), dtype=np.float32)
    cursor = 0

    batch_frames = []
    for start in range(0, len(cells), args.cell_batch_size):
        stop = min(start + args.cell_batch_size, len(cells))
        batch_frames.append(cells.iloc[start:stop].copy().sort_values(["source_file", "source_row"]).reset_index(drop=True))

    for batch, (input_matrix, target_matrix) in zip(
        batch_frames,
        iter_materialized_batches(batch_frames, reader, input_union_columns, target_union_columns, batch_executor),
    ):
        input_tensor = torch.from_numpy(input_matrix).to(device)
        target_tensor = torch.from_numpy(target_matrix).to(device)
        batch_pair_cells = np.repeat(np.arange(len(batch), dtype=np.int64), gene_indices.size)
        batch_pair_targets = np.tile(gene_indices, len(batch))

        for pair_start in range(0, batch_pair_cells.size, args.pair_batch_size):
            pair_end = min(pair_start + args.pair_batch_size, batch_pair_cells.size)
            cells_t = torch.as_tensor(batch_pair_cells[pair_start:pair_end], device=device)
            targets_t = torch.as_tensor(batch_pair_targets[pair_start:pair_end], device=device)
            masked = mask_batch(input_tensor, target_input_positions, cells_t, targets_t)
            if model.use_promoter:
                promoter_np = promoter_batch(
                    contexts,
                    target_context_rows,
                    batch_pair_targets[pair_start:pair_end],
                    0,
                    args.promoter_radius,
                )
                promoter = torch.from_numpy(promoter_np).to(device)
                batch_predictions = model(masked, promoter)
            else:
                batch_predictions = model(masked)

            label_values = target_tensor[cells_t, targets_t].float().cpu().numpy()
            pred_values = batch_predictions.float().cpu().numpy()
            batch_size = pair_end - pair_start
            predictions[cursor:cursor + batch_size] = pred_values
            truths[cursor:cursor + batch_size] = label_values
            cursor += batch_size

    prediction_matrix = predictions.reshape(len(cells), len(gene_indices))
    truth_matrix = truths.reshape(len(cells), len(gene_indices))
    return regression_metrics(truth_matrix, prediction_matrix), prediction_matrix


def train_model(
    model: PromoterExpressionModel,
    reader: AtlasExpressionReader,
    train_cells: pd.DataFrame,
    val_cells: pd.DataFrame,
    train_gene_indices: np.ndarray,
    val_gene_indices: np.ndarray,
    target_input_positions: torch.Tensor,
    contexts: np.ndarray,
    target_context_rows: np.ndarray,
    input_union_columns: np.ndarray,
    target_union_columns: np.ndarray,
    batch_executor: ProcessPoolExecutor | None,
    args: argparse.Namespace,
    device: torch.device,
    contrastive_positive_contexts: np.ndarray | None = None,
    negative_contexts: np.ndarray | None = None,
    negative_context_rows: np.ndarray | None = None,
) -> tuple[list[dict[str, object]], dict[str, object]]:
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.learning_rate, weight_decay=args.weight_decay)
    loss_function = nn.MSELoss()
    rng = np.random.default_rng(args.seed)
    promoter_max_shift = contexts.shape[1] // 2 - args.promoter_radius
    if promoter_max_shift < 0:
        raise ValueError(
            f"promoter radius {args.promoter_radius} exceeds cached radius {contexts.shape[1] // 2}"
        )
    ema = ExponentialMovingAverage(model, args.ema_decay) if args.ema_decay > 0 else None
    if contrastive_positive_contexts is None:
        contrastive_positive_contexts = contexts
    triplet_loss = nn.TripletMarginLoss(margin=args.contrastive_margin)

    def train_epoch(epoch: int) -> float:
        model.train()
        epoch_cells = train_cells
        if args.max_train_cells_per_epoch > 0 and len(epoch_cells) > args.max_train_cells_per_epoch:
            epoch_cells = sample_frame(epoch_cells, args.max_train_cells_per_epoch, args.seed + epoch)
        epoch_cells = epoch_cells.sample(frac=1.0, random_state=args.seed + epoch).reset_index(drop=True)
        epoch_batches = build_cell_batches(epoch_cells, args.cell_batch_size)
        train_loss_sum = 0.0
        train_examples = 0

        for batch_frame, (input_matrix, target_matrix) in zip(
            epoch_batches,
            iter_materialized_batches(epoch_batches, reader, input_union_columns, target_union_columns, batch_executor),
        ):
            input_tensor = torch.from_numpy(input_matrix).to(device)
            target_tensor = torch.from_numpy(target_matrix).to(device)
            cell_count = len(batch_frame)
            pair_count = cell_count * args.targets_per_cell
            pair_cells = rng.choice(np.arange(cell_count, dtype=np.int64), size=pair_count, replace=True)
            pair_targets = rng.choice(train_gene_indices, size=pair_count, replace=True)
            order = rng.permutation(pair_cells.size)
            pair_cells = pair_cells[order]
            pair_targets = pair_targets[order]

            for pair_start in range(0, pair_cells.size, args.pair_batch_size):
                pair_end = min(pair_start + args.pair_batch_size, pair_cells.size)
                cells_t = torch.as_tensor(pair_cells[pair_start:pair_end], device=device)
                targets_t = torch.as_tensor(pair_targets[pair_start:pair_end], device=device)
                masked = mask_batch(input_tensor, target_input_positions, cells_t, targets_t)
                if model.use_promoter:
                    shifts = sample_shifts(pair_end - pair_start, rng, max_shift=promoter_max_shift)
                    promoter_np = promoter_batch(
                        contexts,
                        target_context_rows,
                        pair_targets[pair_start:pair_end],
                        shifts,
                        args.promoter_radius,
                    )
                    promoter = torch.from_numpy(promoter_np).to(device)
                    predictions = model(masked, promoter)
                else:
                    predictions = model(masked)
                labels = target_tensor[cells_t, targets_t]
                optimizer.zero_grad(set_to_none=True)
                loss = loss_function(predictions, labels)
                if (
                    model.use_promoter
                    and args.contrastive_weight > 0
                    and negative_contexts is not None
                    and negative_context_rows is not None
                ):
                    shifts_a = sample_shifts(pair_end - pair_start, rng, max_shift=promoter_max_shift)
                    shifts_b = sample_shifts(pair_end - pair_start, rng, max_shift=promoter_max_shift)
                    positive_a_np = promoter_batch(
                        contrastive_positive_contexts,
                        target_context_rows,
                        pair_targets[pair_start:pair_end],
                        shifts_a,
                        args.promoter_radius,
                    )
                    positive_b_np = promoter_batch(
                        contrastive_positive_contexts,
                        target_context_rows,
                        pair_targets[pair_start:pair_end],
                        shifts_b,
                        args.promoter_radius,
                    )
                    negative_np = promoter_batch(
                        negative_contexts,
                        negative_context_rows,
                        pair_targets[pair_start:pair_end],
                        0,
                        args.promoter_radius,
                    )
                    anchor = F.normalize(model.encode_promoter(torch.from_numpy(positive_a_np).to(device)), dim=1)
                    positive = F.normalize(model.encode_promoter(torch.from_numpy(positive_b_np).to(device)), dim=1)
                    negative = F.normalize(model.encode_promoter(torch.from_numpy(negative_np).to(device)), dim=1)
                    loss = loss + args.contrastive_weight * triplet_loss(anchor, positive, negative)
                loss.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
                optimizer.step()
                if ema is not None:
                    ema.update(model)

                batch_examples = pair_end - pair_start
                train_loss_sum += float(loss.item()) * batch_examples
                train_examples += batch_examples

        return train_loss_sum / max(train_examples, 1)

    def evaluate_epoch(epoch: int) -> tuple[dict[str, float], dict[str, object]]:
        if ema is not None:
            ema.store(model)
        try:
            val_metrics, _ = evaluate_split(
                model,
                reader,
                val_cells,
                val_gene_indices,
                target_input_positions,
                contexts,
                target_context_rows,
                input_union_columns,
                target_union_columns,
                batch_executor,
                args,
                device,
            )
            candidate_state = {
                "model_state_dict": copy.deepcopy(model.state_dict()),
                "epoch": epoch,
                "val_metrics": val_metrics,
                "args": vars(args),
            }
            return val_metrics, {"candidate_state": candidate_state}
        finally:
            if ema is not None:
                ema.restore(model)

    def log_epoch(epoch: int, train_mse: float, val_metrics: dict[str, float]) -> None:
        print(
            f"epoch={epoch:03d} train_mse={train_mse:.6f} "
            f"val_rmse={val_metrics['rmse']:.6f} val_r={val_metrics['pearson_all_values']:.4f}",
            flush=True,
        )

    result = run_patience_training(
        train_epoch_fn=train_epoch,
        evaluate_fn=evaluate_epoch,
        patience=args.patience,
        max_epochs=args.epochs,
        log_epoch_fn=log_epoch,
    )
    if result.best_state is None:
        raise RuntimeError("training did not produce a best checkpoint")
    return result.history, result.best_state["candidate_state"]


def main() -> None:
    args = parse_args()
    if args.contrastive_weight > 0 and (
        args.mode != "expression_plus_promoter" or args.promoter_control != "matched"
    ):
        raise ValueError(
            "promoter/intergenic contrastive loss uses true promoter positives and "
            "is only valid for matched promoter runs; set --contrastive-weight 0 "
            "for expression-only or control-sequence runs"
        )
    args.output_dir.mkdir(parents=True, exist_ok=True)
    seed_everything(args.seed)
    device = torch.device(args.device)

    cells = read_cell_index(args.index_dir)
    input_panel, target_panel = load_panel_tables(args.panel_dir, args.promoter_dir)

    train_cells = cells.copy().reset_index(drop=True)
    val_cells = sample_frame(cells, args.validation_cells, args.seed)
    test_cells = sample_frame(cells, args.test_cells, args.seed + 1)

    if len(train_cells) == 0:
        raise ValueError("no training cells available")

    train_gene_indices = target_panel.index[target_panel["gene_split"].map(normalize_gene_split) == "train"].to_numpy(dtype=np.int64)
    val_gene_indices = target_panel.index[target_panel["gene_split"].map(normalize_gene_split) == "validation"].to_numpy(dtype=np.int64)
    test_gene_indices = target_panel.index[target_panel["gene_split"].map(normalize_gene_split) == "test"].to_numpy(dtype=np.int64)
    if len(train_gene_indices) == 0 or len(val_gene_indices) == 0 or len(test_gene_indices) == 0:
        raise ValueError(
            "target panel must include non-empty train, validation, and test gene splits"
        )

    files = sorted(args.input_dir.glob(args.pattern))
    if not files:
        raise FileNotFoundError(f"no files matched {args.pattern!r} in {args.input_dir}")
    with h5py.File(files[0], "r") as handle:
        n_features = int(handle["layers"][args.expression_layer].attrs["shape"][1])

    union_feature_indices, union_lookup, input_union_columns, target_union_columns, target_feature_indices = build_feature_lookups(
        n_features,
        input_panel,
        target_panel,
    )
    target_input_positions = torch.from_numpy(target_panel["input_position"].fillna(-1).astype(np.int64).to_numpy())
    target_context_rows = target_panel["context_row"].to_numpy(dtype=np.int64)
    target_gene_splits = target_panel["gene_split"].map(normalize_gene_split).to_numpy()

    promoter_contexts = np.load(args.promoter_dir / "promoter_contexts.uint8.npy", mmap_mode="r")
    contrastive_positive_contexts = promoter_contexts
    negative_contexts = None
    negative_context_rows = None
    if args.promoter_control == "intergenic_matched":
        if args.intergenic_dir is None:
            raise ValueError("intergenic_dir is required for intergenic_matched control")
        intergenic_contexts, intergenic_rows = load_intergenic_contexts(
            args.intergenic_dir,
            target_panel["feature_index"].to_numpy(),
            promoter_contexts.shape[1],
        )
        control_contexts = intergenic_contexts
        control_context_rows = intergenic_rows
    else:
        control_contexts, control_context_rows = build_control_contexts(
            promoter_contexts,
            target_context_rows,
            args.promoter_control,
            args.seed,
            groups=target_gene_splits,
        )
    negative_contexts = None
    negative_context_rows = None
    if args.contrastive_weight > 0:
        if args.intergenic_dir is None:
            raise ValueError("intergenic_dir is required for contrastive learning")
        negative_contexts, negative_context_rows = load_intergenic_contexts(
            args.intergenic_dir,
            target_panel["feature_index"].to_numpy(),
            promoter_contexts.shape[1],
        )

    model = PromoterExpressionModel(
        len(input_panel),
        use_promoter=args.mode == "expression_plus_promoter",
        promoter_encoder_kind=args.promoter_encoder,
        promoter_length=2 * args.promoter_radius + 1,
    ).to(device)

    reader = AtlasExpressionReader(
        args.input_dir,
        union_lookup,
        n_features,
        args.expression_layer,
    )
    batch_executor = None
    if args.num_workers > 1:
        batch_executor = ProcessPoolExecutor(
            max_workers=args.num_workers,
            initializer=_init_batch_worker,
            initargs=(
                args.input_dir,
                union_lookup,
                n_features,
                args.expression_layer,
                input_union_columns,
                target_union_columns,
            ),
        )

    started = time.perf_counter()
    try:
        history, best_state = train_model(
            model=model,
            reader=reader,
            train_cells=train_cells,
            val_cells=val_cells,
            train_gene_indices=train_gene_indices,
            val_gene_indices=val_gene_indices,
            target_input_positions=target_input_positions.to(device),
            contexts=control_contexts,
            target_context_rows=control_context_rows,
            input_union_columns=input_union_columns,
            target_union_columns=target_union_columns,
            batch_executor=batch_executor,
            args=args,
            device=device,
            contrastive_positive_contexts=promoter_contexts,
            negative_contexts=negative_contexts,
            negative_context_rows=negative_context_rows,
        )

        checkpoint_path = args.output_dir / "best_model.pt"
        torch.save(best_state, checkpoint_path)
        checkpoint = torch.load(checkpoint_path, map_location=device, weights_only=False)
        model.load_state_dict(checkpoint["model_state_dict"])

        eval_sets = {
            "train_cells_train_genes": sample_frame(train_cells, min(len(train_cells), args.test_cells), args.seed + 10),
            "validation_cells_validation_genes": val_cells,
            "test_cells_test_genes": test_cells,
        }
        eval_gene_sets = {
            "train_cells_train_genes": train_gene_indices,
            "validation_cells_validation_genes": val_gene_indices,
            "test_cells_test_genes": test_gene_indices,
        }
        eval_results = {}
        for name, cells_subset in eval_sets.items():
            metrics, _ = evaluate_split(
                model,
                reader,
                cells_subset,
                eval_gene_sets[name],
                target_input_positions.to(device),
                control_contexts,
                control_context_rows,
                input_union_columns,
                target_union_columns,
                batch_executor,
                args,
                device,
            )
            eval_results[name] = {
                "n_cells": int(len(cells_subset)),
                "n_genes": int(len(eval_gene_sets[name])),
                **metrics,
            }

        summary = {
            "mode": args.mode,
            "promoter_control": args.promoter_control,
            "promoter_encoder": args.promoter_encoder,
            "promoter_radius": args.promoter_radius,
            "ema_decay": args.ema_decay,
            "contrastive_weight": args.contrastive_weight,
            "contrastive_margin": args.contrastive_margin,
            "intergenic_dir": str(args.intergenic_dir) if args.intergenic_dir else "",
            "cell_pool": "all",
            "best_epoch": checkpoint["epoch"],
            "best_val_rmse": checkpoint["val_metrics"]["rmse"],
            "validation": checkpoint["val_metrics"],
            "split_design": "gene_promoter_split_all_cells",
            "evaluations": eval_results,
            "elapsed_seconds": time.perf_counter() - started,
            "device": str(device),
            "parameters": sum(parameter.numel() for parameter in model.parameters()),
            "train_cell_count": int(len(train_cells)),
            "validation_cell_count": int(len(val_cells)),
            "test_cell_count": int(len(test_cells)),
            "train_gene_count": int(len(train_gene_indices)),
            "validation_gene_count": int(len(val_gene_indices)),
            "test_gene_count": int(len(test_gene_indices)),
            "gene_split_policy": "gene_promoter_only",
            "validation_selection_axis": "validation_genes",
            "config": {
                "seed": args.seed,
                "epochs": args.epochs,
                "patience": args.patience,
                "num_workers": args.num_workers,
                "cell_batch_size": args.cell_batch_size,
                "pair_batch_size": args.pair_batch_size,
                "targets_per_cell": args.targets_per_cell,
                "learning_rate": args.learning_rate,
                "weight_decay": args.weight_decay,
                "max_train_cells_per_epoch": args.max_train_cells_per_epoch,
                "validation_cells": args.validation_cells,
                "test_cells": args.test_cells,
                "cell_pool": "all",
                "promoter_radius": args.promoter_radius,
            },
        }
        dump_json(args.output_dir / "summary.json", summary, indent=2)
        dump_json(args.output_dir / "history.json", history, indent=2)
    finally:
        if batch_executor is not None:
            batch_executor.shutdown(cancel_futures=True)
        reader.close()


if __name__ == "__main__":
    main()
