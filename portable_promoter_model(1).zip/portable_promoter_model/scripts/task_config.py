#!/usr/bin/env python3
"""Load standalone task configuration files."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Mapping


def _merge_config_sections(
    target: dict[str, Any],
    source: Mapping[str, Any],
    source_path: tuple[str, ...] = (),
) -> None:
    for key, value in source.items():
        if not isinstance(key, str):
            raise TypeError(
                f"task config keys must be strings: {'.'.join(source_path) or '<root>'}"
            )
        if isinstance(value, Mapping):
            _merge_config_sections(target, value, source_path + (key,))
            continue
        if key in target:
            location = '.'.join(source_path + (key,))
            raise ValueError(f"duplicate task config key {key!r} while processing {location}")
        target[key] = value


def load_task_config(path: Path) -> dict[str, Any]:
    with path.open('r', encoding='utf-8') as handle:
        data = json.load(handle)
    if not isinstance(data, dict):
        raise TypeError(f"task config must be a JSON object: {path}")
    flattened: dict[str, Any] = {}
    _merge_config_sections(flattened, data)
    return flattened
