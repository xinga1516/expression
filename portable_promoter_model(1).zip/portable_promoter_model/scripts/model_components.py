#!/usr/bin/env python3
"""Model components used by the portable promoter training workflow."""

from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd
import torch
from torch import nn

from promoter_model.promoters import slice_shifted_contexts


SPLIT_CODEBOOK = {"train": 0, "validation": 1, "val": 1, "test": 2}


class PromoterExpressionModel(nn.Module):
    def __init__(
        self,
        n_inputs: int,
        use_promoter: bool,
        promoter_encoder_kind: str = "cnn_bilstm",
        promoter_length: int = 401,
    ) -> None:
        super().__init__()
        self.use_promoter = use_promoter
        self.promoter_encoder_kind = promoter_encoder_kind
        self.promoter_length = promoter_length
        self.cell_encoder = nn.Sequential(
            nn.Linear(n_inputs, 256),
            nn.LayerNorm(256),
            nn.GELU(),
            nn.Dropout(0.10),
            nn.Linear(256, 128),
            nn.LayerNorm(128),
            nn.GELU(),
        )
        if use_promoter:
            self.promoter_embedding = nn.Embedding(5, 8)
            self.promoter_conv = nn.Sequential(
                nn.Conv1d(8, 32, kernel_size=9, padding=4),
                nn.GELU(),
                nn.Conv1d(32, 32, kernel_size=7, padding=3),
                nn.GELU(),
            )
            if promoter_encoder_kind == "cnn_pool":
                self.promoter_tail = nn.AdaptiveAvgPool1d(1)
                promoter_width = 32
            elif promoter_encoder_kind == "cnn_bilstm":
                self.promoter_tail = nn.LSTM(
                    input_size=32,
                    hidden_size=32,
                    num_layers=1,
                    batch_first=True,
                    bidirectional=True,
                )
                promoter_width = 64
            else:
                raise ValueError(f"unexpected promoter_encoder_kind: {promoter_encoder_kind}")
            regressor_width = 128 + promoter_width
        else:
            regressor_width = 128
        self.regressor = nn.Sequential(
            nn.Linear(regressor_width, 128),
            nn.GELU(),
            nn.Dropout(0.10),
            nn.Linear(128, 1),
        )

    def encode_promoter(self, promoter: torch.Tensor) -> torch.Tensor:
        promoter = self.promoter_embedding(promoter.long()).transpose(1, 2)
        features = self.promoter_conv(promoter)
        if self.promoter_encoder_kind == "cnn_pool":
            return self.promoter_tail(features).squeeze(-1)
        features = features.transpose(1, 2)
        _, (hidden_state, _) = self.promoter_tail(features)
        return torch.cat([hidden_state[-2], hidden_state[-1]], dim=1)

    def forward(
        self,
        expression: torch.Tensor,
        promoter: torch.Tensor | None = None,
    ) -> torch.Tensor:
        cell_state = self.cell_encoder(expression)
        if self.use_promoter:
            if promoter is None:
                raise ValueError("promoter input is required for this model")
            features = torch.cat([cell_state, self.encode_promoter(promoter)], dim=1)
        else:
            features = cell_state
        return self.regressor(features)[:, 0]


class ExponentialMovingAverage:
    def __init__(self, model: nn.Module, decay: float) -> None:
        if not 0.0 < decay < 1.0:
            raise ValueError("EMA decay must be in (0, 1)")
        self.decay = decay
        self.shadow = {
            name: parameter.detach().clone()
            for name, parameter in model.named_parameters()
            if parameter.requires_grad
        }
        self.backup: dict[str, torch.Tensor] = {}

    def update(self, model: nn.Module) -> None:
        with torch.no_grad():
            for name, parameter in model.named_parameters():
                if not parameter.requires_grad:
                    continue
                shadow_parameter = self.shadow[name]
                shadow_parameter.mul_(self.decay).add_(parameter.detach(), alpha=1.0 - self.decay)

    def store(self, model: nn.Module) -> None:
        self.backup = {}
        for name, parameter in model.named_parameters():
            if not parameter.requires_grad:
                continue
            self.backup[name] = parameter.detach().clone()
            parameter.data.copy_(self.shadow[name])

    def restore(self, model: nn.Module) -> None:
        for name, parameter in model.named_parameters():
            if not parameter.requires_grad:
                continue
            parameter.data.copy_(self.backup[name])
        self.backup = {}


def normalize_gene_split(value: object) -> str:
    split = str(value)
    if split == "val":
        return "validation"
    if split in SPLIT_CODEBOOK:
        return split
    raise ValueError(f"unexpected gene split: {split}")


def build_control_contexts(
    contexts: np.ndarray,
    target_context_rows: np.ndarray,
    control: str,
    seed: int,
    groups: np.ndarray | None = None,
) -> tuple[np.ndarray, np.ndarray]:
    del seed, groups
    if control != "matched":
        raise ValueError(f"unsupported control in current protocol: {control}")
    return contexts, target_context_rows


def resize_context_width(contexts: np.ndarray, target_length: int) -> np.ndarray:
    if contexts.shape[1] == target_length:
        return contexts
    if contexts.shape[1] > target_length:
        start = (contexts.shape[1] - target_length) // 2
        end = start + target_length
        return contexts[:, start:end]
    raise ValueError(f"context width mismatch: expected {target_length}, got {contexts.shape[1]}")


def load_intergenic_contexts(
    intergenic_dir: Path,
    feature_indices: np.ndarray,
    target_length: int,
) -> tuple[np.ndarray, np.ndarray]:
    intergenic_contexts = np.load(intergenic_dir / "intergenic_contexts.uint8.npy", mmap_mode="r")
    intergenic_map = pd.read_csv(
        intergenic_dir / "gene_intergenic.tsv",
        sep="\t",
        usecols=["feature_index", "context_row"],
    ).rename(columns={"context_row": "intergenic_context_row"})
    lookup = pd.DataFrame({"feature_index": np.asarray(feature_indices, dtype=np.int64)})
    lookup = lookup.merge(intergenic_map, on="feature_index", how="left", validate="one_to_one")
    if lookup["intergenic_context_row"].isna().any():
        missing = lookup.loc[lookup["intergenic_context_row"].isna(), "feature_index"].head(10).tolist()
        raise ValueError(f"missing intergenic contexts for features: {missing}")
    return resize_context_width(intergenic_contexts, target_length), lookup["intergenic_context_row"].astype(np.int64).to_numpy()


def _binary_auroc(labels: np.ndarray, scores: np.ndarray) -> float:
    positives = int(labels.sum())
    negatives = int(labels.size - positives)
    if positives == 0 or negatives == 0:
        return float("nan")
    order = np.argsort(scores, kind="mergesort")
    sorted_scores = scores[order]
    ranks = np.empty(labels.size, dtype=np.float64)
    start = 0
    while start < labels.size:
        stop = start + 1
        while stop < labels.size and sorted_scores[stop] == sorted_scores[start]:
            stop += 1
        average_rank = (start + 1 + stop) / 2.0
        ranks[order[start:stop]] = average_rank
        start = stop
    positive_rank_sum = float(ranks[labels].sum())
    return (positive_rank_sum - positives * (positives + 1) / 2) / (positives * negatives)


def _average_precision(labels: np.ndarray, scores: np.ndarray) -> float:
    positives = int(labels.sum())
    if positives == 0:
        return float("nan")
    order = np.argsort(-scores, kind="mergesort")
    sorted_labels = labels[order]
    true_positive_cumsum = np.cumsum(sorted_labels)
    ranks = np.arange(1, labels.size + 1, dtype=np.float64)
    precision = true_positive_cumsum / ranks
    return float(precision[sorted_labels].sum() / positives)


def _average_ranks(values: np.ndarray) -> np.ndarray:
    values = np.asarray(values)
    order = np.argsort(values, kind="mergesort")
    sorted_values = values[order]
    ranks = np.empty(values.size, dtype=np.float64)
    start = 0
    while start < values.size:
        stop = start + 1
        while stop < values.size and sorted_values[stop] == sorted_values[start]:
            stop += 1
        ranks[order[start:stop]] = (start + 1 + stop) / 2.0
        start = stop
    return ranks


def _pearson(x: np.ndarray, y: np.ndarray) -> float:
    if x.size < 2 or x.std() == 0 or y.std() == 0:
        return float("nan")
    return float(np.corrcoef(x, y)[0, 1])


def _spearman(x: np.ndarray, y: np.ndarray) -> float:
    if x.size < 2 or x.std() == 0 or y.std() == 0:
        return float("nan")
    return _pearson(_average_ranks(x), _average_ranks(y))


def _median_defined(values: list[float]) -> float:
    return float(np.median(values)) if values else float("nan")


def regression_metrics(truth: np.ndarray, prediction: np.ndarray) -> dict[str, float]:
    residual = prediction - truth
    residual_flat = residual.ravel()
    truth_flat = truth.ravel()
    prediction_flat = prediction.ravel()
    per_gene_pearson = []
    per_gene_spearman = []
    per_gene_spearman_nonzero_ge_005 = []
    n_genes_nonzero_ge_005 = 0
    for target_index in range(truth.shape[1]):
        target_truth = truth[:, target_index]
        target_prediction = prediction[:, target_index]
        pearson = _pearson(target_truth, target_prediction)
        if not np.isnan(pearson):
            per_gene_pearson.append(pearson)
        spearman = _spearman(target_truth, target_prediction)
        if not np.isnan(spearman):
            per_gene_spearman.append(spearman)
        if float((target_truth > 0).mean()) >= 0.05:
            n_genes_nonzero_ge_005 += 1
            if not np.isnan(spearman):
                per_gene_spearman_nonzero_ge_005.append(spearman)

    per_cell_pearson = []
    per_cell_spearman = []
    for cell_index in range(truth.shape[0]):
        cell_truth = truth[cell_index, :]
        cell_prediction = prediction[cell_index, :]
        pearson = _pearson(cell_truth, cell_prediction)
        if not np.isnan(pearson):
            per_cell_pearson.append(pearson)
        spearman = _spearman(cell_truth, cell_prediction)
        if not np.isnan(spearman):
            per_cell_spearman.append(spearman)

    nonzero_mask = truth_flat > 0
    zero_mask = truth_flat == 0
    top_k = max(1, int(np.ceil(truth_flat.size * 0.10)))
    top_indices = np.argpartition(truth_flat, -top_k)[-top_k:]
    expressed_labels = nonzero_mask.astype(bool)
    return {
        "rmse": float(np.sqrt(np.mean(residual_flat**2))),
        "mae": float(np.mean(np.abs(residual_flat))),
        "pearson_all_values": _pearson(truth_flat, prediction_flat),
        "spearman_all_values": _spearman(truth_flat, prediction_flat),
        "median_per_gene_pearson": _median_defined(per_gene_pearson),
        "n_genes_with_defined_pearson": len(per_gene_pearson),
        "median_per_gene_spearman": _median_defined(per_gene_spearman),
        "n_genes_with_defined_spearman": len(per_gene_spearman),
        "median_per_gene_spearman_nonzero_ge_005": _median_defined(per_gene_spearman_nonzero_ge_005),
        "n_genes_nonzero_ge_005": n_genes_nonzero_ge_005,
        "n_genes_nonzero_ge_005_with_defined_spearman": len(per_gene_spearman_nonzero_ge_005),
        "median_per_cell_pearson": _median_defined(per_cell_pearson),
        "n_cells_with_defined_pearson": len(per_cell_pearson),
        "median_per_cell_spearman": _median_defined(per_cell_spearman),
        "n_cells_with_defined_spearman": len(per_cell_spearman),
        "zero_fraction": float(zero_mask.mean()),
        "positive_fraction": float(nonzero_mask.mean()),
        "nonzero_rmse": float(np.sqrt(np.mean(residual_flat[nonzero_mask] ** 2))) if np.any(nonzero_mask) else float("nan"),
        "nonzero_mae": float(np.mean(np.abs(residual_flat[nonzero_mask])) if np.any(nonzero_mask) else float("nan")),
        "zero_rmse": float(np.sqrt(np.mean(residual_flat[zero_mask] ** 2))) if np.any(zero_mask) else float("nan"),
        "zero_mae": float(np.mean(np.abs(residual_flat[zero_mask]))) if np.any(zero_mask) else float("nan"),
        "pred_positive_rate_at_zero": float((prediction_flat > 0).mean()),
        "expressed_auroc": _binary_auroc(expressed_labels, prediction_flat),
        "expressed_average_precision": _average_precision(expressed_labels, prediction_flat),
        "top_expression_decile_rmse": float(np.sqrt(np.mean(residual_flat[top_indices] ** 2))),
    }


def mask_batch(
    input_expression: torch.Tensor,
    target_input_positions: torch.Tensor,
    cell_indices: torch.Tensor,
    target_indices: torch.Tensor,
) -> torch.Tensor:
    expression = input_expression[cell_indices].clone()
    positions = target_input_positions[target_indices]
    present = positions >= 0
    rows = torch.nonzero(present, as_tuple=False)[:, 0]
    expression[rows, positions[present]] = 0.0
    return expression


def promoter_batch(
    contexts: np.ndarray,
    target_context_rows: np.ndarray,
    target_indices: np.ndarray,
    shifts: np.ndarray | int,
    promoter_radius: int,
) -> np.ndarray:
    row_indices = target_context_rows[target_indices]
    batch_contexts = contexts[row_indices]
    return slice_shifted_contexts(batch_contexts, shifts, promoter_radius=promoter_radius)
