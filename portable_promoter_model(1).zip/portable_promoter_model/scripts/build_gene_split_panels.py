#!/usr/bin/env python3
"""Build current-protocol input and target panels for gene/promoter holdout."""

from __future__ import annotations

import argparse
from pathlib import Path

import h5py
import numpy as np
import pandas as pd

from atlas_io import decode_text
from script_common import dump_json


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input-dir", type=Path, required=True)
    parser.add_argument("--promoter-metadata", type=Path, required=True)
    parser.add_argument("--gene-split-plan", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--pattern", default="*.h5ad")
    parser.add_argument("--expression-layer", default="log_normalized")
    parser.add_argument("--n-input-features", type=int, default=4096)
    parser.add_argument(
        "--n-target-features",
        type=int,
        default=0,
        help="0 keeps all promoter-ok target genes; a positive value keeps a stratified subset.",
    )
    parser.add_argument("--seed", type=int, default=1)
    return parser.parse_args()


def csr_matrix_group(group: h5py.Group) -> tuple[h5py.Dataset, h5py.Dataset, h5py.Dataset, tuple[int, int]]:
    if decode_text(group.attrs.get("encoding-type", "")) != "csr_matrix":
        raise TypeError(f"expected csr_matrix group, found {group.name}")
    shape = tuple(int(value) for value in group.attrs["shape"])
    return group["data"], group["indices"], group["indptr"], shape


def accumulate_csr_layer(group: h5py.Group) -> tuple[np.ndarray, np.ndarray, np.ndarray, int]:
    data, indices, indptr, shape = csr_matrix_group(group)
    n_rows, n_columns = shape
    sum_ = np.zeros(n_columns, dtype=np.float64)
    sumsq = np.zeros(n_columns, dtype=np.float64)
    nnz = np.zeros(n_columns, dtype=np.int64)
    for row in range(n_rows):
        start = int(indptr[row])
        end = int(indptr[row + 1])
        if start == end:
            continue
        row_indices = indices[start:end]
        row_data = data[start:end].astype(np.float64, copy=False)
        sum_[row_indices] += row_data
        sumsq[row_indices] += row_data * row_data
        nnz[row_indices] += 1
    return sum_, sumsq, nnz, int(n_rows)


def load_split_plan(path: Path) -> dict[str, str]:
    plan = pd.read_csv(path, sep="\t")
    required = {"chrom", "split"}
    missing = required.difference(plan.columns)
    if missing:
        raise KeyError(f"gene split plan missing columns: {sorted(missing)}")
    allowed = {"train", "validation", "test"}
    bad = sorted(set(plan["split"].astype(str)) - allowed)
    if bad:
        raise ValueError(f"unsupported split labels: {bad}")
    return dict(zip(plan["chrom"].astype(str), plan["split"].astype(str), strict=True))


def rank_percentile_bins(values: pd.Series, n_bins: int = 4) -> pd.Series:
    ranked = values.rank(method="first", pct=True)
    bins = np.floor((ranked.to_numpy(dtype=np.float64) - np.finfo(np.float64).eps) * n_bins).astype(int)
    return pd.Series(np.clip(bins, 0, n_bins - 1), index=values.index)


def stratified_target_subset(candidates: pd.DataFrame, n_targets: int, seed: int) -> pd.DataFrame:
    if n_targets <= 0 or len(candidates) <= n_targets:
        return candidates.copy()
    candidates = candidates.copy().reset_index(drop=True)
    candidates["mean_bin"] = rank_percentile_bins(candidates["train_log_mean"])
    candidates["detection_bin"] = rank_percentile_bins(candidates["train_detection_fraction"])
    candidates["variance_bin"] = rank_percentile_bins(candidates["train_log_variance"])
    candidates["stratum"] = (
        candidates["gene_split"]
        + "|"
        + candidates["mean_bin"].astype(str)
        + "|"
        + candidates["detection_bin"].astype(str)
        + "|"
        + candidates["variance_bin"].astype(str)
    )
    rng = np.random.default_rng(seed)
    parts = []
    per_split = candidates["gene_split"].value_counts(normalize=True)
    quotas = {
        split: max(1, int(round(n_targets * float(fraction))))
        for split, fraction in per_split.items()
    }
    while sum(quotas.values()) > n_targets:
        split = max(quotas, key=quotas.get)
        quotas[split] -= 1
    while sum(quotas.values()) < n_targets:
        split = min(quotas, key=quotas.get)
        quotas[split] += 1
    for split, quota in quotas.items():
        split_frame = candidates[candidates["gene_split"] == split]
        if len(split_frame) <= quota:
            parts.append(split_frame)
        else:
            parts.append(split_frame.iloc[rng.permutation(len(split_frame))[:quota]])
    return pd.concat(parts, ignore_index=True)


def main() -> None:
    args = parse_args()
    files = sorted(args.input_dir.glob(args.pattern))
    if not files:
        raise FileNotFoundError(f"no files matched {args.pattern!r} in {args.input_dir}")
    split_plan = load_split_plan(args.gene_split_plan)
    promoter = pd.read_csv(args.promoter_metadata, sep="\t")

    required = {"feature_index", "gene_id", "input_gene_symbol", "chrom", "status", "sequence_qc"}
    missing = required.difference(promoter.columns)
    if missing:
        raise KeyError(f"promoter metadata missing columns: {sorted(missing)}")

    global_sum = None
    global_sumsq = None
    global_nnz = None
    global_rows = 0
    feature_count = None
    for path in files:
        print(f"reading expression stats: {path.name}", flush=True)
        with h5py.File(path, "r") as handle:
            layer = handle["layers"][args.expression_layer]
            sum_, sumsq, nnz, n_rows = accumulate_csr_layer(layer)
        if feature_count is None:
            feature_count = len(sum_)
            global_sum = np.zeros(feature_count, dtype=np.float64)
            global_sumsq = np.zeros(feature_count, dtype=np.float64)
            global_nnz = np.zeros(feature_count, dtype=np.int64)
        elif len(sum_) != feature_count:
            raise ValueError(f"feature count mismatch in {path.name}")
        global_sum += sum_
        global_sumsq += sumsq
        global_nnz += nnz
        global_rows += n_rows

    if feature_count is None or global_sum is None or global_sumsq is None or global_nnz is None:
        raise RuntimeError("no expression stats were accumulated")

    metrics = pd.DataFrame(
        {
            "feature_index": np.arange(feature_count, dtype=np.int64),
            "train_cell_count": global_rows,
            "train_log_mean": global_sum / max(global_rows, 1),
            "train_log_variance": np.maximum((global_sumsq / max(global_rows, 1)) - (global_sum / max(global_rows, 1)) ** 2, 0.0),
            "train_detection_fraction": global_nnz / max(global_rows, 1),
        }
    )
    metrics = metrics.merge(
        promoter[
            [
                "feature_index",
                "gene_id",
                "input_gene_symbol",
                "chrom",
                "status",
                "sequence_qc",
            ]
        ],
        on="feature_index",
        how="inner",
        validate="one_to_one",
    )
    metrics["gene_split"] = metrics["chrom"].astype(str).map(split_plan).fillna("train")
    metrics["eligible"] = (
        (metrics["status"] == "ok")
        & (metrics["sequence_qc"] == "pass")
        & metrics["gene_split"].isin(["train", "validation", "test"])
    )
    eligible = metrics[metrics["eligible"]].copy()

    input_candidates = eligible[
        (eligible["gene_split"] == "train")
        & eligible["train_detection_fraction"].between(0.01, 0.99)
    ].copy()
    input_panel = input_candidates.sort_values(
        ["train_log_variance", "train_detection_fraction", "gene_id"],
        ascending=[False, False, True],
    ).head(args.n_input_features).copy()
    if len(input_panel) != args.n_input_features:
        raise ValueError(f"requested {args.n_input_features} input genes, found {len(input_panel)}")
    input_panel.insert(0, "input_position", np.arange(len(input_panel), dtype=np.int64))

    target_panel = stratified_target_subset(eligible, args.n_target_features, args.seed)
    target_panel = target_panel.sort_values(["gene_split", "gene_id"]).reset_index(drop=True)
    target_panel.insert(0, "target_index", np.arange(len(target_panel), dtype=np.int64))
    input_positions = dict(zip(input_panel["feature_index"], input_panel["input_position"], strict=True))
    target_panel["input_position"] = target_panel["feature_index"].map(input_positions).fillna(-1).astype(int)

    args.output_dir.mkdir(parents=True, exist_ok=True)
    input_panel[
        [
            "input_position",
            "feature_index",
            "gene_id",
            "input_gene_symbol",
            "gene_split",
            "train_detection_fraction",
            "train_log_mean",
            "train_log_variance",
        ]
    ].to_csv(args.output_dir / "input_features.tsv", sep="\t", index=False)
    target_panel[
        [
            "target_index",
            "feature_index",
            "gene_id",
            "input_gene_symbol",
            "gene_split",
            "train_detection_fraction",
            "train_log_mean",
            "train_log_variance",
            "input_position",
        ]
    ].to_csv(args.output_dir / "target_genes.tsv", sep="\t", index=False)
    metrics.to_csv(args.output_dir / "panel_gene_metrics.tsv", sep="\t", index=False)

    split_counts = target_panel["gene_split"].value_counts().to_dict()
    summary = {
        "n_files": len(files),
        "n_cells": int(global_rows),
        "n_input_features": int(len(input_panel)),
        "n_target_features": int(len(target_panel)),
        "target_gene_split_counts": {split: int(split_counts.get(split, 0)) for split in ("train", "validation", "test")},
        "input_features_from_split": "train",
        "target_features_from_splits": ["train", "validation", "test"],
        "missing_chromosomes_defaulted_to_train": sorted(set(metrics["chrom"].astype(str)) - set(split_plan)),
    }
    dump_json(args.output_dir / "summary.json", summary, indent=2)


if __name__ == "__main__":
    main()
