#!/usr/bin/env python3
"""Load task-specific training defaults from standalone config files."""

from __future__ import annotations

from pathlib import Path

from task_config import load_task_config


def default_training_config_path(name: str) -> Path:
    return Path(__file__).resolve().parent.parent / "configs" / "training" / f"{name}.json"


def load_training_config(path: Path):
    return load_task_config(path)
