# Portable Promoter Model

这个文件夹是一个干净的、可迁移的 promoter 序列建模包。它只包含当前推荐方法：

1. 从新物种的 `.h5ad`、FASTA、GTF 构建 strand-oriented promoter 序列。
2. 为每个 gene 构建 matched intergenic 非启动子序列。
3. 按 gene/promoter 做 train/validation/test 划分，细胞全部作为训练采样池。
4. 训练四个最小必要模型：
   - `expression_only`
   - matched promoter with contrastive loss
   - matched promoter without contrastive loss
   - matched intergenic control without contrastive loss
5. 在 validation genes 上选 checkpoint，在 test genes 上做最终报告。

这个包不包含任何项目历史记录、旧实验分支、旧 run 结果、checkpoint、数据文件或物种专用资源。

## Directory Layout

- `scripts/`: 可直接运行的数据处理和训练入口。
- `src/promoter_model/`: promoter 序列切片和 split helper。
- `configs/training/`: 当前主线训练默认参数。
- `configs/templates/`: 新物种需要填写的模板。
- `docs/`: 方法逻辑、输入契约和复现实验协议。
- `examples/run_pipeline.sh`: 一条从数据准备到训练的命令模板。
- `environment.yml`: 推荐 Conda 环境。

## Recommended Reading Order

1. `docs/METHOD_SUMMARY.md`
2. `docs/INPUT_CONTRACTS.md`
3. `docs/MIGRATION_GUIDE.md`
4. `docs/EXPERIMENT_PROTOCOL.md`
5. `examples/run_pipeline.sh`

## Core Claim

只有当 matched promoter 模型在 unseen validation/test genes 上稳定优于 `expression_only` 和 clean matched intergenic control，才说明模型以端到端方式利用了启动子序列信息，而不是只利用细胞状态、基因身份泄漏或一般序列组成。
