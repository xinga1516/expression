# Package Manifest

## Reusable Code

- `scripts/build_promoter_contexts.py`
- `scripts/build_intergenic_contexts.py`
- `scripts/build_cell_index.py`
- `scripts/build_gene_split_panels.py`
- `scripts/train_promoter_model.py`
- `scripts/model_components.py`
- `scripts/atlas_io.py`
- `scripts/context_asset_utils.py`
- `scripts/script_common.py`
- `scripts/task_config.py`
- `scripts/training_config.py`
- `scripts/training_common.py`
- `scripts/training_engine.py`
- `src/promoter_model/promoters.py`
- `src/promoter_model/pairs.py`
- `src/promoter_model/splits.py`

## Configs And Templates

- `configs/training/promoter_model.json`
- `configs/templates/species_project.yaml`
- `configs/templates/gene_split_plan.tsv`

## Documentation

- `README.md`
- `docs/METHOD_SUMMARY.md`
- `docs/MIGRATION_GUIDE.md`
- `docs/INPUT_CONTRACTS.md`
- `docs/EXPERIMENT_PROTOCOL.md`
- `examples/run_pipeline.sh`
- `environment.yml`

## Not Included

- Reference genomes, GTF files, or single-cell `.h5ad` files.
- Generated arrays, model checkpoints, run logs, or result tables.
- Superseded strategies, side branches, or project-specific historical records.
